﻿function GetUrlParam(paraName) {
    var url = document.location.toString();
    var arrObj = url.split("?");

    if (arrObj.length > 1) {
        var arrPara = arrObj[1].split("&");
        var arr;

        for (var i = 0; i < arrPara.length; i++) {
            arr = arrPara[i].split("=");

            if (arr != null && arr[0] == paraName) {
                return arr[1];
            }
        }
        return "";
    }
    else {
        return "";
    }
}
var la = GetUrlParam("gj");

if (la != null) {
    switch (la) {
        case "fr":
            if (document.getElementById("h_cart") != null) {
                document.getElementById("h_cart").innerHTML = "Panier";
            }
            if (document.getElementById("c_cart") != null) {
                document.getElementById("c_cart").innerHTML = "Panier";
            }
            if (document.getElementById("h_home") != null) {
                document.getElementById("h_home").innerHTML = "Accueil";
            }
            if (document.getElementById("f_home") != null) {
                document.getElementById("f_home").innerHTML = "Accueil";
            }
            if (document.getElementById("n_home") != null) {
                document.getElementById("n_home").innerHTML = "Accueil";
            }
            if (document.getElementById("f_as") != null) {
                document.getElementById("f_as").innerHTML = "à propos de nous";
            }
            if (document.getElementById("f_cs") != null) {
                document.getElementById("f_cs").innerHTML = "Contactez nous";
            }
            if (document.getElementById("f_payment") != null) {
                document.getElementById("f_payment").innerHTML = "Paiement";
            }
            if (document.getElementById("n_free") != null) {
                document.getElementById("n_free").innerHTML = "Livraison gratuite";
            }
            if (document.getElementById("n_size") != null) {
                document.getElementById("n_size").innerHTML = "Taille";
            }
            if (document.getElementById("n_number") != null) {
                document.getElementById("n_number").innerHTML = "Nombre";
            }
            if (document.getElementById("add") != null) {
                document.getElementById("add").innerHTML = "Ajouter au panier";
            }
            if (document.getElementById("n_ms") != null) {
                document.getElementById("n_ms").innerHTML = "détails du produit";
            }
            if (document.getElementById("n_like") != null) {
                document.getElementById("n_like").innerHTML = "Les clients ayant acheté cet article ont également acheté";
            }
            if (document.getElementById("c_head") != null) {
                document.getElementById("c_head").innerHTML = "Les articles suivants sont inclus dans le panier";
            }
            if (document.getElementById("c_head_2") != null) {
                document.getElementById("c_head_2").innerHTML = "détails de la commande";
            }

            if (document.getElementById("c_q") != null) {
                document.getElementById("c_q").innerHTML = "Quantité";
            }
            if (document.getElementById("c_t") != null) {
                document.getElementById("c_t").innerHTML = "Total";
            }
            if (document.getElementById("c_t1") != null) {
                document.getElementById("c_t1").innerHTML = "Total";
            }
            if (document.getElementById("c_f") != null) {
                document.getElementById("c_f").innerHTML = "Frais de Port";
            }
            if (document.getElementById("sgj") != null) {
                document.getElementById("sgj").value = "FRANCE";
            }
            if (document.getElementById("drpcountry") != null) {
                var gggg = document.getElementById("drpcountry");
                for (var i = 0; i < gggg.options.length; i++) {
                    if (gggg.options[i].value == "FR") {
                        gggg.options[i].selected = true;
                        break;
                    }
                }
            }
            if (document.getElementById("ch_province") != null) {
                document.getElementById("ch_province").setAttribute("placeholder", "Province");
            }
            if (document.getElementById("jp_village") != null) {
                document.getElementById("jp_village").setAttribute("placeholder", "Ville");
            }
            if (document.getElementById("jp_town") != null) {
                document.getElementById("jp_town").setAttribute("placeholder", "Adresse");
            }
            if (document.getElementById("receiver") != null) {
                document.getElementById("receiver").setAttribute("placeholder", "Nom complet");
            }
            if (document.getElementById("zipcod") != null) {
                document.getElementById("zipcod").setAttribute("placeholder", "Code postal");
            }
            if (document.getElementById("receiver_phone") != null) {
                document.getElementById("receiver_phone").setAttribute("placeholder", "Numéro de téléphone");
            }
            if (document.getElementById("remark") != null) {
                document.getElementById("remark").setAttribute("placeholder", "Remarques et messages");
            }
            if (document.getElementById("sp") != null) {
                document.getElementById("sp").innerHTML = "Paiement par carte de crédit";
            }
            if (document.getElementById("btncc") != null) {
                document.getElementById("btncc").innerHTML = "Confirmation de commande &gt;";
            }


            if (document.getElementById("c_card") != null) {
                document.getElementById("c_card").innerHTML = "Numéro de carte";
            }
            if (document.getElementById("c_time") != null) {
                document.getElementById("c_time").innerHTML = "Date d'expiration";
            }
            if (document.getElementById("c_code") != null) {
                document.getElementById("c_code").innerHTML = "Code de sécurité";
            }
            if (document.getElementById("c_aq") != null) {
                document.getElementById("c_aq").innerHTML = "Nous tenons au respect de votre vie privée. Nous traiterons vos données personnelles conformément à notre politique de confidentialité.";
            }
            if (document.getElementById("c_aq1") != null) {
                document.getElementById("c_aq1").innerHTML = "Tous les champs sont obligatoires pour traiter votre commande";
            }
            if (document.getElementById("submit") != null) {
                document.getElementById("submit").value = "PAIEMENT";
            }
            if (document.getElementById("c_dd") != null) {
                document.getElementById("c_dd").innerHTML = "S'il vous plaît attendre, le paiement est entrain de transfert ...";
            }
            if (document.getElementById("cvvhelp") != null) {
                document.getElementById("cvvhelp").innerHTML = "Qù le trouver?";
            }
            break;







        case "it":
            if (document.getElementById("h_cart") != null) {
                document.getElementById("h_cart").innerHTML = "Carrello";
            }
            if (document.getElementById("c_cart") != null) {
                document.getElementById("c_cart").innerHTML = "Carrello";
            }
            if (document.getElementById("h_home") != null) {
                document.getElementById("h_home").innerHTML = "Casa";
            }
            if (document.getElementById("f_home") != null) {
                document.getElementById("f_home").innerHTML = "Casa";
            }
            if (document.getElementById("n_home") != null) {
                document.getElementById("n_home").innerHTML = "Casa";
            }
            if (document.getElementById("f_as") != null) {
                document.getElementById("f_as").innerHTML = "Riguardo a noi";
            }
            if (document.getElementById("f_cs") != null) {
                document.getElementById("f_cs").innerHTML = "Contattaci";
            }
            if (document.getElementById("f_payment") != null) {
                document.getElementById("f_payment").innerHTML = "Pagamento";
            }
            if (document.getElementById("n_free") != null) {
                document.getElementById("n_free").innerHTML = "Spedizione gratuita";
            }
            if (document.getElementById("n_size") != null) {
                document.getElementById("n_size").innerHTML = "Taglia";
            }
            if (document.getElementById("n_number") != null) {
                document.getElementById("n_number").innerHTML = "Numero";
            }
            if (document.getElementById("add") != null) {
                document.getElementById("add").innerHTML = "Aggiungi al carrello";
            }
            if (document.getElementById("n_ms") != null) {
                document.getElementById("n_ms").innerHTML = "Dettagli del prodotto";
            }
            if (document.getElementById("n_like") != null) {
                document.getElementById("n_like").innerHTML = "I clienti che hanno acquistato questo prodotto hanno acquistato anche";
            }
            if (document.getElementById("c_head") != null) {
                document.getElementById("c_head").innerHTML = "I seguenti articoli sono inclusi nel carrello";
            }
            if (document.getElementById("c_head_2") != null) {
                document.getElementById("c_head_2").innerHTML = "dettagli dell'ordine";
            }

            if (document.getElementById("c_q") != null) {
                document.getElementById("c_q").innerHTML = "Quantità";
            }
            if (document.getElementById("c_t") != null) {
                document.getElementById("c_t").innerHTML = "Totale";
            }
            if (document.getElementById("c_t1") != null) {
                document.getElementById("c_t1").innerHTML = "Totale";
            }
            if (document.getElementById("c_f") != null) {
                document.getElementById("c_f").innerHTML = "trasporto";
            }
            if (document.getElementById("sgj") != null) {
                document.getElementById("sgj").value = "ITALY";
            }
            if (document.getElementById("drpcountry") != null) {
                var gggg = document.getElementById("drpcountry");
                for (var i = 0; i < gggg.options.length; i++) {
                    if (gggg.options[i].value == "IT") {
                        gggg.options[i].selected = true;
                        break;
                    }
                }
            }
            if (document.getElementById("ch_province") != null) {
                document.getElementById("ch_province").setAttribute("placeholder", "Provincia");
            }
            if (document.getElementById("jp_village") != null) {
                document.getElementById("jp_village").setAttribute("placeholder", "Città");
            }
            if (document.getElementById("jp_town") != null) {
                document.getElementById("jp_town").setAttribute("placeholder", "Indirizzo");
            }
            if (document.getElementById("receiver") != null) {
                document.getElementById("receiver").setAttribute("placeholder", "Nome e cognome");
            }
            if (document.getElementById("zipcod") != null) {
                document.getElementById("zipcod").setAttribute("placeholder", "Codice postale");
            }
            if (document.getElementById("receiver_phone") != null) {
                document.getElementById("receiver_phone").setAttribute("placeholder", "Numero di telefono");
            }
            if (document.getElementById("remark") != null) {
                document.getElementById("remark").setAttribute("placeholder", "Note e messaggi");
            }
            if (document.getElementById("sp") != null) {
                document.getElementById("sp").innerHTML = "Pagamento con carta di credito";
            }
            if (document.getElementById("btncc") != null) {
                document.getElementById("btncc").innerHTML = "Conferma dell'ordine &gt;";
            }
            if (document.getElementById("c_card") != null) {
                document.getElementById("c_card").innerHTML = "Numero di carta";
            }
            if (document.getElementById("c_time") != null) {
                document.getElementById("c_time").innerHTML = "Data di scadenza";
            }
            if (document.getElementById("c_code") != null) {
                document.getElementById("c_code").innerHTML = "Codice di sicurezza";
            }
            if (document.getElementById("c_aq") != null) {
                document.getElementById("c_aq").innerHTML = "Rispettiamo la tua privacy. Tratteremo i tuoi dati personali in conformità con la nostra politica sulla privacy.";
            }
            if (document.getElementById("c_aq1") != null) {
                document.getElementById("c_aq1").innerHTML = "Tutti i campi sono necessari per elaborare il tuo ordine";
            }
            if (document.getElementById("submit") != null) {
                document.getElementById("submit").value = "PAGAMENTO";
            }
            if (document.getElementById("c_dd") != null) {
                document.getElementById("c_dd").innerHTML = "Si prega di attendere, il pagamento è il trasferimento ...";
            }
            if (document.getElementById("cvvhelp") != null) {
                document.getElementById("cvvhelp").innerHTML = "Dove trovarlo?";
            }
            break;












        case "es":
            if (document.getElementById("h_cart") != null) {
                document.getElementById("h_cart").innerHTML = "Carrito";
            }
            if (document.getElementById("c_cart") != null) {
                document.getElementById("c_cart").innerHTML = "Carrito";
            }
            if (document.getElementById("h_home") != null) {
                document.getElementById("h_home").innerHTML = "Casa";
            }
            if (document.getElementById("f_home") != null) {
                document.getElementById("f_home").innerHTML = "Casa";
            }
            if (document.getElementById("n_home") != null) {
                document.getElementById("n_home").innerHTML = "Casa";
            }
            if (document.getElementById("f_as") != null) {
                document.getElementById("f_as").innerHTML = "Sobre nosotros";
            }
            if (document.getElementById("f_cs") != null) {
                document.getElementById("f_cs").innerHTML = "Contáctenos";
            }
            if (document.getElementById("f_payment") != null) {
                document.getElementById("f_payment").innerHTML = "Pago";
            }
            if (document.getElementById("n_free") != null) {
                document.getElementById("n_free").innerHTML = "Envío gratis";
            }
            if (document.getElementById("n_size") != null) {
                document.getElementById("n_size").innerHTML = "tamaño";
            }
            if (document.getElementById("n_number") != null) {
                document.getElementById("n_number").innerHTML = "Número";
            }
            if (document.getElementById("add") != null) {
                document.getElementById("add").innerHTML = "Añadir a la cesta";
            }
            if (document.getElementById("n_ms") != null) {
                document.getElementById("n_ms").innerHTML = "detalles del producto";
            }
            if (document.getElementById("n_like") != null) {
                document.getElementById("n_like").innerHTML = "Los clientes que compraron este artículo también compraron";
            }
            if (document.getElementById("c_head") != null) {
                document.getElementById("c_head").innerHTML = "Los siguientes artículos están incluidos en el carrito de compras.";
            }
            if (document.getElementById("c_head_2") != null) {
                document.getElementById("c_head_2").innerHTML = "detalles del pedido";
            }

            if (document.getElementById("c_q") != null) {
                document.getElementById("c_q").innerHTML = "Cantidad";
            }
            if (document.getElementById("c_t") != null) {
                document.getElementById("c_t").innerHTML = "Total";
            }
            if (document.getElementById("c_t1") != null) {
                document.getElementById("c_t1").innerHTML = "Total";
            }
            if (document.getElementById("c_f") != null) {
                document.getElementById("c_f").innerHTML = "La carga";
            }
            if (document.getElementById("sgj") != null) {
                document.getElementById("sgj").value = "SPAIN";
            }
            if (document.getElementById("drpcountry") != null) {
                var gggg = document.getElementById("drpcountry");
                for (var i = 0; i < gggg.options.length; i++) {
                    if (gggg.options[i].value == "ES") {
                        gggg.options[i].selected = true;
                        break;
                    }
                }
            }
            if (document.getElementById("ch_province") != null) {
                document.getElementById("ch_province").setAttribute("placeholder", "Provincia");
            }
            if (document.getElementById("jp_village") != null) {
                document.getElementById("jp_village").setAttribute("placeholder", "Ciudad");
            }
            if (document.getElementById("jp_town") != null) {
                document.getElementById("jp_town").setAttribute("placeholder", "Dirección");
            }
            if (document.getElementById("receiver") != null) {
                document.getElementById("receiver").setAttribute("placeholder", "Nombre completo");
            }
            if (document.getElementById("zipcod") != null) {
                document.getElementById("zipcod").setAttribute("placeholder", "código postal");
            }
            if (document.getElementById("receiver_phone") != null) {
                document.getElementById("receiver_phone").setAttribute("placeholder", "Número de teléfono");
            }
            if (document.getElementById("remark") != null) {
                document.getElementById("remark").setAttribute("placeholder", "Notas y mensajes");
            }
            if (document.getElementById("sp") != null) {
                document.getElementById("sp").innerHTML = "Pago con tarjeta de crédito";
            }
            if (document.getElementById("btncc") != null) {
                document.getElementById("btncc").innerHTML = "Confirmación del pedido &gt;";
            }
            if (document.getElementById("c_card") != null) {
                document.getElementById("c_card").innerHTML = "Número de tarjeta";
            }
            if (document.getElementById("c_time") != null) {
                document.getElementById("c_time").innerHTML = "Fecha de caducidad";
            }
            if (document.getElementById("c_code") != null) {
                document.getElementById("c_code").innerHTML = "Código de seguridad";
            }
            if (document.getElementById("c_aq") != null) {
                document.getElementById("c_aq").innerHTML = "Respetamos tu privacidad. Trataremos sus datos personales de acuerdo con nuestra política de privacidad.";
            }
            if (document.getElementById("c_aq1") != null) {
                document.getElementById("c_aq1").innerHTML = "Todos los campos son requeridos para procesar su orden.";
            }
            if (document.getElementById("submit") != null) {
                document.getElementById("submit").value = "PAGO";
            }
            if (document.getElementById("c_dd") != null) {
                document.getElementById("c_dd").innerHTML = "Por favor espere, el pago es transferencia. ...";
            }
            if (document.getElementById("cvvhelp") != null) {
                document.getElementById("cvvhelp").innerHTML = "Donde encontrarlo?";
            }
            break;








        case "de":
            if (document.getElementById("h_cart") != null) {
                document.getElementById("h_cart").innerHTML = "Einkaufswagen";
            }
            if (document.getElementById("c_cart") != null) {
                document.getElementById("c_cart").innerHTML = "Einkaufswagen";
            }
            if (document.getElementById("h_home") != null) {
                document.getElementById("h_home").innerHTML = "Zuhause";
            }
            if (document.getElementById("f_home") != null) {
                document.getElementById("f_home").innerHTML = "Zuhause";
            }
            if (document.getElementById("n_home") != null) {
                document.getElementById("n_home").innerHTML = "Zuhause";
            }
            if (document.getElementById("f_as") != null) {
                document.getElementById("f_as").innerHTML = "Über uns";
            }
            if (document.getElementById("f_cs") != null) {
                document.getElementById("f_cs").innerHTML = "Kontaktiere uns";
            }
            if (document.getElementById("f_payment") != null) {
                document.getElementById("f_payment").innerHTML = "Zahlung";
            }
            if (document.getElementById("n_free") != null) {
                document.getElementById("n_free").innerHTML = "Kostenloser Versand";
            }
            if (document.getElementById("n_size") != null) {
                document.getElementById("n_size").innerHTML = "Größe";
            }
            if (document.getElementById("n_number") != null) {
                document.getElementById("n_number").innerHTML = "Nummer";
            }
            if (document.getElementById("add") != null) {
                document.getElementById("add").innerHTML = "In den Warenkorb legen";
            }
            if (document.getElementById("n_ms") != null) {
                document.getElementById("n_ms").innerHTML = "Produktdetails";
            }
            if (document.getElementById("n_like") != null) {
                document.getElementById("n_like").innerHTML = "Kunden, die diesen Artikel kauften, kauften auch";
            }
            if (document.getElementById("c_head") != null) {
                document.getElementById("c_head").innerHTML = "Die folgenden Artikel sind im Warenkorb enthalten";
            }
            if (document.getElementById("c_head_2") != null) {
                document.getElementById("c_head_2").innerHTML = "Details der Bestellung";
            }

            if (document.getElementById("c_q") != null) {
                document.getElementById("c_q").innerHTML = "Menge";
            }
            if (document.getElementById("c_t") != null) {
                document.getElementById("c_t").innerHTML = "Gesamt";
            }
            if (document.getElementById("c_t1") != null) {
                document.getElementById("c_t1").innerHTML = "Gesamt";
            }
            if (document.getElementById("c_f") != null) {
                document.getElementById("c_f").innerHTML = "Fracht";
            }
            if (document.getElementById("sgj") != null) {
                document.getElementById("sgj").value = "GERMANY";
            }
            if (document.getElementById("drpcountry") != null) {
                var gggg = document.getElementById("drpcountry");
                for (var i = 0; i < gggg.options.length; i++) {
                    if (gggg.options[i].value == "DE") {
                        gggg.options[i].selected = true;
                        break;
                    }
                }
            }
            if (document.getElementById("ch_province") != null) {
                document.getElementById("ch_province").setAttribute("placeholder", "Provinz");
            }
            if (document.getElementById("jp_village") != null) {
                document.getElementById("jp_village").setAttribute("placeholder", "Stadt");
            }
            if (document.getElementById("jp_town") != null) {
                document.getElementById("jp_town").setAttribute("placeholder", "Adresse");
            }
            if (document.getElementById("receiver") != null) {
                document.getElementById("receiver").setAttribute("placeholder", "Vollständiger Name");
            }
            if (document.getElementById("zipcod") != null) {
                document.getElementById("zipcod").setAttribute("placeholder", "Postleitzahl");
            }
            if (document.getElementById("receiver_phone") != null) {
                document.getElementById("receiver_phone").setAttribute("placeholder", "Telefonnummer");
            }
            if (document.getElementById("remark") != null) {
                document.getElementById("remark").setAttribute("placeholder", "Notizen und Nachrichten");
            }
            if (document.getElementById("sp") != null) {
                document.getElementById("sp").innerHTML = "Zahlung mit Kreditkarte";
            }
            if (document.getElementById("btncc") != null) {
                document.getElementById("btncc").innerHTML = "Bestellbestätigung &gt;";
            }
            if (document.getElementById("c_card") != null) {
                document.getElementById("c_card").innerHTML = "Kartennummer";
            }
            if (document.getElementById("c_time") != null) {
                document.getElementById("c_time").innerHTML = "Haltbarkeitsdatum";
            }
            if (document.getElementById("c_code") != null) {
                document.getElementById("c_code").innerHTML = "Sicherheitscode";
            }
            if (document.getElementById("c_aq") != null) {
                document.getElementById("c_aq").innerHTML = "Wir respektieren deine Privatsphäre. Wir werden Ihre personenbezogenen Daten gemäß unserer Datenschutzerklärung behandeln.";
            }
            if (document.getElementById("c_aq1") != null) {
                document.getElementById("c_aq1").innerHTML = "Alle Felder sind erforderlich, um Ihre Bestellung zu bearbeiten";
            }
            if (document.getElementById("submit") != null) {
                document.getElementById("submit").value = "ZAHLUNG";
            }
            if (document.getElementById("c_dd") != null) {
                document.getElementById("c_dd").innerHTML = "Bitte warten Sie, die Zahlung erfolgt per Überweisung ...";
            }
            if (document.getElementById("cvvhelp") != null) {
                document.getElementById("cvvhelp").innerHTML = "Wo finde ich das?";
            }
            break;








        case "nl":
            if (document.getElementById("h_cart") != null) {
                document.getElementById("h_cart").innerHTML = "Winkelwagen";
            }
            if (document.getElementById("c_cart") != null) {
                document.getElementById("c_cart").innerHTML = "Winkelwagen";
            }
            if (document.getElementById("h_home") != null) {
                document.getElementById("h_home").innerHTML = "Huis";
            }
            if (document.getElementById("f_home") != null) {
                document.getElementById("f_home").innerHTML = "Huis";
            }
            if (document.getElementById("n_home") != null) {
                document.getElementById("n_home").innerHTML = "Huis";
            }
            if (document.getElementById("f_as") != null) {
                document.getElementById("f_as").innerHTML = "Over ons";
            }
            if (document.getElementById("f_cs") != null) {
                document.getElementById("f_cs").innerHTML = "Contacteer ons";
            }
            if (document.getElementById("f_payment") != null) {
                document.getElementById("f_payment").innerHTML = "Betaling";
            }
            if (document.getElementById("n_free") != null) {
                document.getElementById("n_free").innerHTML = "Gratis verzending";
            }
            if (document.getElementById("n_size") != null) {
                document.getElementById("n_size").innerHTML = "Grootte";
            }
            if (document.getElementById("n_number") != null) {
                document.getElementById("n_number").innerHTML = "Aantal";
            }
            if (document.getElementById("add") != null) {
                document.getElementById("add").innerHTML = "Voeg toe aan winkelmandje";
            }
            if (document.getElementById("n_ms") != null) {
                document.getElementById("n_ms").innerHTML = "Productdetails";
            }
            if (document.getElementById("n_like") != null) {
                document.getElementById("n_like").innerHTML = "Klanten die dit artikel kochten, kochten ook";
            }
            if (document.getElementById("c_head") != null) {
                document.getElementById("c_head").innerHTML = "De volgende items zijn opgenomen in het winkelwagentje";
            }
            if (document.getElementById("c_head_2") != null) {
                document.getElementById("c_head_2").innerHTML = "details van de bestelling";
            }

            if (document.getElementById("c_q") != null) {
                document.getElementById("c_q").innerHTML = "Aantal stuks";
            }
            if (document.getElementById("c_t") != null) {
                document.getElementById("c_t").innerHTML = "Totaal";
            }
            if (document.getElementById("c_t1") != null) {
                document.getElementById("c_t1").innerHTML = "Totaal";
            }
            if (document.getElementById("c_f") != null) {
                document.getElementById("c_f").innerHTML = "vracht";
            }
            if (document.getElementById("sgj") != null) {
                document.getElementById("sgj").value = "NETHERLANDS";
            }
            if (document.getElementById("drpcountry") != null) {
                var gggg = document.getElementById("drpcountry");
                for (var i = 0; i < gggg.options.length; i++) {
                    if (gggg.options[i].value == "NL") {
                        gggg.options[i].selected = true;
                        break;
                    }
                }
            }
            if (document.getElementById("ch_province") != null) {
                document.getElementById("ch_province").setAttribute("placeholder", "Provincie");
            }
            if (document.getElementById("jp_village") != null) {
                document.getElementById("jp_village").setAttribute("placeholder", "Stad");
            }
            if (document.getElementById("jp_town") != null) {
                document.getElementById("jp_town").setAttribute("placeholder", "Adres");
            }
            if (document.getElementById("receiver") != null) {
                document.getElementById("receiver").setAttribute("placeholder", "Voor-en achternaam");
            }
            if (document.getElementById("zipcod") != null) {
                document.getElementById("zipcod").setAttribute("placeholder", "Postcode");
            }
            if (document.getElementById("receiver_phone") != null) {
                document.getElementById("receiver_phone").setAttribute("placeholder", "Telefoon nummer");
            }
            if (document.getElementById("remark") != null) {
                document.getElementById("remark").setAttribute("placeholder", "Aantekeningen en berichten");
            }
            if (document.getElementById("sp") != null) {
                document.getElementById("sp").innerHTML = "Betaling per creditcard";
            }
            if (document.getElementById("btncc") != null) {
                document.getElementById("btncc").innerHTML = "Order bevestiging &gt;";
            }
            if (document.getElementById("c_card") != null) {
                document.getElementById("c_card").innerHTML = "Kaartnummer";
            }
            if (document.getElementById("c_time") != null) {
                document.getElementById("c_time").innerHTML = "Uiterste houdbaarheidsdatum";
            }
            if (document.getElementById("c_code") != null) {
                document.getElementById("c_code").innerHTML = "Beveiligingscode";
            }
            if (document.getElementById("c_aq") != null) {
                document.getElementById("c_aq").innerHTML = "We respecteren uw privacy. We zullen uw persoonlijke gegevens behandelen in overeenstemming met ons privacybeleid.";
            }
            if (document.getElementById("c_aq1") != null) {
                document.getElementById("c_aq1").innerHTML = "Alle velden zijn vereist om uw bestelling te verwerken";
            }
            if (document.getElementById("submit") != null) {
                document.getElementById("submit").value = "BETALING";
            }
            if (document.getElementById("c_dd") != null) {
                document.getElementById("c_dd").innerHTML = "Even geduld aub, de betaling is overschrijving ...";
            }
            if (document.getElementById("cvvhelp") != null) {
                document.getElementById("cvvhelp").innerHTML = "Waar het te vinden?";
            }
            break;





       


        default:
            if (document.getElementById("h_cart") != null) {
                document.getElementById("h_cart").innerHTML = "Shooping Cart";
            }
            if (document.getElementById("c_cart") != null) {
                document.getElementById("c_cart").innerHTML = "Shooping Cart";
            }
            if (document.getElementById("h_home") != null) {
                document.getElementById("h_home").innerHTML = "Home";
            }
            if (document.getElementById("f_home") != null) {
                document.getElementById("f_home").innerHTML = "Home";
            }
            if (document.getElementById("n_home") != null) {
                document.getElementById("n_home").innerHTML = "Home";
            }
            if (document.getElementById("f_as") != null) {
                document.getElementById("f_as").innerHTML = "About Us";
            }
            if (document.getElementById("f_cs") != null) {
                document.getElementById("f_cs").innerHTML = "Contact Us";
            }
            if (document.getElementById("f_payment") != null) {
                document.getElementById("f_payment").innerHTML = "Payment";
            }
            if (document.getElementById("n_free") != null) {
                document.getElementById("n_free").innerHTML = "Free shipping";
            }
            if (document.getElementById("n_size") != null) {
                document.getElementById("n_size").innerHTML = "Size";
            }
            if (document.getElementById("n_number") != null) {
                document.getElementById("n_number").innerHTML = "Number";
            }
            if (document.getElementById("add") != null) {
                document.getElementById("add").innerHTML = "Add to cart";
            }
            if (document.getElementById("n_ms") != null) {
                document.getElementById("n_ms").innerHTML = "product details";
            }
            if (document.getElementById("n_like") != null) {
                document.getElementById("n_like").innerHTML = "Customers who bought this item also bought";
            }
            if (document.getElementById("c_head") != null) {
                document.getElementById("c_head").innerHTML = "The following items are included in the Shooping Cart";
            }
            if (document.getElementById("c_head_2") != null) {
                document.getElementById("c_head_2").innerHTML = "details of the order";
            }

            if (document.getElementById("c_q") != null) {
                document.getElementById("c_q").innerHTML = "Quantity";
            }
            if (document.getElementById("c_t") != null) {
                document.getElementById("c_t").innerHTML = "Total";
            }
            if (document.getElementById("c_t1") != null) {
                document.getElementById("c_t1").innerHTML = "Total";
            }
            if (document.getElementById("c_f") != null) {
                document.getElementById("c_f").innerHTML = "Freight";
            }
            if (document.getElementById("sgj") != null) {
                document.getElementById("sgj").value = "UNITED STATES";
            }
            if (document.getElementById("drpcountry") != null) {
                var gggg = document.getElementById("drpcountry");
                for (var i = 0; i < gggg.options.length; i++) {
                    if (gggg.options[i].value == "US") {
                        gggg.options[i].selected = true;
                        break;
                    }
                }
            }
            if (document.getElementById("ch_province") != null) {
                document.getElementById("ch_province").setAttribute("placeholder", "Province");
            }
            if (document.getElementById("jp_village") != null) {
                document.getElementById("jp_village").setAttribute("placeholder", "City");
            }
            if (document.getElementById("jp_town") != null) {
                document.getElementById("jp_town").setAttribute("placeholder", "Address");
            }
            if (document.getElementById("receiver") != null) {
                document.getElementById("receiver").setAttribute("placeholder", "Full Name");
            }
            if (document.getElementById("zipcod") != null) {
                document.getElementById("zipcod").setAttribute("placeholder", "Postal code");
            }
            if (document.getElementById("receiver_phone") != null) {
                document.getElementById("receiver_phone").setAttribute("placeholder", "Telephone number");
            }
            if (document.getElementById("remark") != null) {
                document.getElementById("remark").setAttribute("placeholder", "Notes and messages");
            }
            if (document.getElementById("sp") != null) {
                document.getElementById("sp").innerHTML = "Payment by credit card";
            }
            if (document.getElementById("btncc") != null) {
                document.getElementById("btncc").innerHTML = "Order confirmation &gt;";
            }


            if (document.getElementById("c_card") != null) {
                document.getElementById("c_card").innerHTML = "Card number";
            }
            if (document.getElementById("c_time") != null) {
                document.getElementById("c_time").innerHTML = "Expiration date";
            }
            if (document.getElementById("c_code") != null) {
                document.getElementById("c_code").innerHTML = "Security code";
            }
            if (document.getElementById("c_aq") != null) {
                document.getElementById("c_aq").innerHTML = "We respect your privacy. We will treat your personal data in accordance with our privacy policy.";
            }
            if (document.getElementById("c_aq1") != null) {
                document.getElementById("c_aq1").innerHTML = "All fields are required to process your order";
            }
            if (document.getElementById("submit") != null) {
                document.getElementById("submit").value = "PAYMENT";
            }
            if (document.getElementById("c_dd") != null) {
                document.getElementById("c_dd").innerHTML = "Please wait, the payment is transfer ...";
            }
            if (document.getElementById("cvvhelp") != null) {
                document.getElementById("cvvhelp").innerHTML = "Where to find it?";
            }
            break;
    }
}