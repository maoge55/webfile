﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;

public partial class s : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) { bindimgs(); }
    }
    public string wdgj = "com";
    public string wdprice = "";
    public void bindimgs()
    {

        if ((Request.QueryString["cid"] != null && Request.QueryString["cid"] != ""))
        {
            SqlParameter[] paraj = { new SqlParameter("@kcid", SqlDbType.Int) };
            paraj[0].Value = Request.QueryString["cid"];

            DataSet dsos = GetDataSet("selectJC", paraj);
            wdprice = dsos.Tables[0].Rows[0][0].ToString();
            wdgj = dsos.Tables[0].Rows[0][1].ToString();
            //string csize = dsos.Tables[0].Rows[0][2].ToString();



            int zs = 0;
            int allpnum = 0;
            DataSet dsallkeys = new DataSet();
            string sqlstr = "";

            SqlParameter[] para ={
                                     new SqlParameter("@pageSize",SqlDbType.Int),
                                     new SqlParameter("@pageIndex",SqlDbType.Int),
                                      new SqlParameter("@pageCount",SqlDbType.Int),
                                       new SqlParameter("@recodNumber",SqlDbType.Int),
                                     new SqlParameter("@kcid",SqlDbType.Int)};

            int pnum = 1;
            if (Request.QueryString["pnum"] != null)
            {
                try
                {
                    pnum = int.Parse(Request.QueryString["pnum"]);
                }
                catch
                {

                }
            }
            para[0].Value = int.Parse(Request.QueryString["number"]);
            para[1].Value = pnum;
            para[2].Direction = ParameterDirection.Output;
            para[3].Direction = ParameterDirection.Output;
            para[4].Value = int.Parse(Request.QueryString["cid"]);
            dsallkeys = GetDataSet("JD_pagelist_FristImg", para);
            if (para[2].Value != null && para[3].Value != null)
            {
                zs = int.Parse(para[2].Value.ToString());
                allpnum = int.Parse(para[3].Value.ToString());
            }

            if (access_sql.yzTable(dsallkeys))
            {


                int min = 50;
                int max = 90;
                if (wdprice != "" && wdprice.Contains("-"))
                {
                    min = int.Parse(wdprice.Split('-')[0]);
                    max = int.Parse(wdprice.Split('-')[1]);
                }
                string xi = "0";
                string xc = "10";

                string txturl = Request.QueryString["txt"];
                string txtcon = "";
                int cs = 0;



                cs++;
                string pl = Request.QueryString["pl"];
                string you = Request.QueryString["you"];
                StringBuilder str = new StringBuilder();




                // str.Append("<div style='width: 100%;float: left;'><ul style='width: 100%;float: left;'>");
                // for (int i = 1; i <= allpnum; i++)
                //{
                // str.Append("<li style='float: left;list-style: none;width:2%'> <a href=\"?cid=" + Request.QueryString["cid"] + "&pnum=" + i + "\" >" + i + "</a></li>");
                //}
                //str.Append("</ul></div>");
                str.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
                str.Append("<urlset xmlns=\"http://www.google.com/schemas/sitemap/0.84\">\r\n");
                DataTable dtt = SJDataTable(dsallkeys.Tables[0]);
                for (int i = 0; i < dtt.Rows.Count; i++)
                {

                    string price = "";
                    if (wdprice != "" && wdprice.Contains("-"))
                    {
                        price = getprice(min, max) + ".99";
                    }
                    else
                    {
                        price = wdprice;
                    }
                    if (Request.QueryString["xi"] != null && Request.QueryString["xc"] != null && Request.QueryString["xi"] != "" && Request.QueryString["xc"] != "")
                    {
                        xi = Request.QueryString["xi"];
                        xc = Request.QueryString["xc"];
                    }

                    if (xi.Contains("-") && xc.Contains("-"))
                    {
                        xi = getprice(int.Parse(xi.Split('-')[0]), int.Parse(xi.Split('-')[1]));
                        xc = getprice(int.Parse(xc.Split('-')[0]), int.Parse(xc.Split('-')[1]));
                    }
                    string key = dtt.Rows[i]["kname"].ToString();
                    string url = "yymm" + "?cname=" + HttpUtility.UrlEncode(key) + "&cid=" + Request.QueryString["cid"];

                    // string url = "yymm" + Request.QueryString["page"] + "?cid=" + Request.QueryString["cid"] + "&shop=" + HttpUtility.UrlEncode(key) + "&xi=" + xi + "&xc=" + xc + "&pr=" + price + (Request.QueryString["you"] == null ? "" : "&you=" + Request.QueryString["you"]);
                    str.Append("<url>\r\n");
                    str.Append("<loc>" + url.Replace("&", "&amp;") + "</loc>\r\n");
                    str.Append("<lastmod>" + DateTime.Now.ToString("yyyy-MM-dd") + "</lastmod>\r\n");
                    str.Append("<changefreq>hourly</changefreq>\r\n");
                    str.Append("<priority>0.8</priority>\r\n");
                    str.Append("</url>\r\n");
                }
                str.Append("</urlset>\r\n");
                Literal1.Text = (str.Replace("&ampamp;", "&amp;")).ToString().Trim();



            }
        }

    }
    public string getprice(int min, int max)
    {
        string ru = "";
        var r = new Random(Guid.NewGuid().GetHashCode());
        ru = r.Next(min, max).ToString(); ;

        return ru;
    }
    public DataTable SJDataTable(DataTable dtTemplate)
    {
        dtTemplate.Columns.Add("ID");
        foreach (DataRow item in dtTemplate.Rows)
        {
            item["id"] = Guid.NewGuid().ToString();
        }
        DataView dv = new DataView(dtTemplate);
        dv.Sort = " id";
        return dv.ToTable();
    }
    public static DataSet GetDataSet(string cmdText, params SqlParameter[] ps)
    {
        DataSet ds = new DataSet();
        try
        {
            using (SqlDataAdapter sda = new SqlDataAdapter(cmdText, ConfigurationSettings.AppSettings["SQLConnectionString"]))
            {
                if (ps != null)
                {
                    sda.SelectCommand.Parameters.AddRange(ps);
                }
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sda.Fill(ds);
            }
            return ds;
        }
        catch (Exception ex)
        {
            ds.Dispose();
            throw (ex);
        }
    }
}