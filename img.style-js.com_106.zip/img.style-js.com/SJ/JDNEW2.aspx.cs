﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Text;
using System.IO.Compression;
using System.Web;
using System.Data;
using System.Data.OleDb;
using System.Threading;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Collections;

public partial class google_action : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
             ym = "https://gift-99.top";
            bindimgs();
            bindLa();
            if (Request.QueryString["iid"] != null)
            {
                bindyoutube();
                bindMS();
                bindSJ();
            }
        }
    }
    public static string[] rrrname = new string[] { "Gilbert", "Giles", "Glenn", "Goddard", "Godfery", "Gordon", "Greg", "Gregary", "Griffith", "Grover", "Gustave", "Guy", "Hale", "Haley", "Hamiltion", "Hardy", "Harlan", "Harley", "Harold", "Harriet", "Harry", "Harvey", "Hayden", "Heather", "Henry", "Herbert", "Herman", "Hilary", "Hiram", "Hobart", "Hogan", "Horace", "Howar", "Hubery", "Hugh", "Hugo", "Humphrey", "Hunter", "Hyman", "Ian", "Ingemar", "Ingram", "Ira", "Isaac", "Isidore", "Ivan", "Ives", "Jack", "Jacob", "James", "Jared", "Jason", "Jay", "Jeff", "Jeffrey", "Jeremy", "Jerome", "Jerry", "Jesse", "Jim", "Jo", "John", "Jonas", "Jonathan", "Joseph", "Joshua", "Joyce", "Julian", "Julius", "Justin", "Keith", "Kelly", "Ken", "Kennedy", "Kenh", "Kent", "Kerr", "Kerwin", "Kevin", "Kim", "King", "Kirk", "Kyle", "Lambert", "Lance", "Larry", "Lawrence", "Leif", "Len", "Lennon", "Leo", "Leonard", "Leopold", "Les", "Lester", "Levi", "Lewis", "Lionel", "Lou", "Louis", "Lucien", "Luther", "Lyle", "Lyndon", "Lynn", "Magee", "Malcolm", "Mandel", "Marcus", "Marico", "Mark", "Marlon", "Marsh", "Marshall", "Martin", "Marvin", "Matt", "Matthew", "Maurice", "Max", "Maximilian", "Maxwell", "Meredith", "Merle", "Merlin", "Michael", "Michell", "Mick", "Mike", "Miles", "Milo", "Monroe", "Montague", "Moore", "Morgan", "Mortimer", "Morton", "Moses", "Murphy", "Murray", "Myron", "Nat", "Nathan", "Nathaniel", "Neil", "Nelson", "Newman", "Nicholas", "Nick", "Nigel", "Noah", "Noel", "Norman", "Norton", "Ogden", "Oliver", "Omar", "orville", "Osborn", "Oscar", "Osmond", "Oswald", "Otis", "Otto", "Owen", "Page", "Parker", "Paddy", "Patrick", "Paul", "Payne", "Perry", "Pete", "Peter", "Phil", "Philip", "Porter", "Prescott", "Primo", "Quentin", "Quennel", "Quincy", "Quinn", "Quintion", "Rachel", "Ralap", "Randolph", "Raymond", "Reg", "Regan", "Reginald", "Reuben", "Rex", "Richard", "Robert", "Robin", "Rock", "Rod", "Roderick", "Rodney", "Ron", "Ronald", "Rory", "Roy", "Rudolf", "Rupert", "Ryan", "Sam", "Sampson", "Samuel", "Sandy", "Saxon", "Scott", "Sean", "Sebastian", "Sid", "Sidney", "Silvester", "Simon", "Solomon", "Spencer", "Stan", "Stanford", "Stanley", "Steven", "Stev", "Steward", "Tab", "Taylor", "Ted", "Ternence", "Theobald", "Theodore", "Thomas", "Tiffany", "Tim", "Timothy", "Tobias", "Toby", "Todd", "Tom", "Tony", "Tracy", "Troy", "Truman", "Tyler", "Tyrone", "Ulysses", "Upton", "Uriah", "Valentine" };
    public static string[] phones = new string[] { "iphone 6s", "iphone 7", "iphone 8", "iphone 11", "iphone 11 Pro", "iphone SE", "iphone 11 Pro Max", "iphone Xs", "iphone X", "iphone XS Max", "iphone 7 Plus", "iphone 6s Plus", "iphone 8 Plus" };
    public static string ym = "";
    public string mpn = "";
    public Double price = 0;
    public string curcode = "";
    public string star = "";
    public string rcount = "";
    public string mainimg = "";
    public string maintitle = "";
    public string curfh = "";
    public string Size = "";
    public string keyword = "";
    public string index_xs = "";
    public string pxstring = "";
    public string pricestring = "";
    public string youtube = "";
    public string Allimgs = "";
    public string Quantity = "";
    public string addtocart = "";
    public string sizetx = "";
    public string Quantitytx = "";
    public string prhead = "";
    public string pdhead = "";
    public string lihead = "";
    public string lihead0 = "";
    public string qdbuton = "";
    public string style = "";
    public string home = "Home";
    public string AboutUS = "About US";
    public string ContactUs = "Contact Us";
    public string Payment = "Payment";
    public string SC = "How to order";
    public string IIF = " Item Information";
    public string sbb = "Search";
    public string stt = "Please enter keywords to search";
    public string crt = "Customer Reviews";
    public string BQ = "© 2019-2023 <a href='HHHHH'>BBBBB</a> All rights reserved.";
    public string url1 = ym + "/page.aspx?la=en&type=1";
    public string url2 = ym + "/page.aspx?la=en&type=2";
    public string url3 = ym + "/page.aspx?la=en&type=3";
    public string url4 = ym + "/page.aspx?la=en&type=4";

    public string rname = "Full Name";
    public string rTitle = "Title";
    public string rrv = "Rating Value";
    public string rt = "Time";
    public string sbb2 = "Submit";
    public string rcontent = "Description";
    public string wdgj = "com";
    public string wdprice = "";
    public void bindLa()
    {


        if (Request.QueryString["gj"] != null || (Request.QueryString["cid"] != null && Request.QueryString["cid"] != "") || cid != 0)
        {
            bindother();
            StringBuilder sizestr = new StringBuilder();
            sizestr.Append("Taille:<select id='size' name='s1'>");
            sizestr.Append("<option value=\"Taille moyenne\">Taille moyenne</option>");
            sizestr.Append("<option value=\"Chaussure Femmes=EU:35=US:5=22.5cm\">Chaussure Femmes=EU:35=US:5</option>");
            sizestr.Append("<option value=\"Chaussure Femmes=EU:36=US:6=23cm\">Chaussure Femmes=EU:36=US:6</option>");
            sizestr.Append("<option value=\"Chaussure Femmes=EU:37=US:6.5=23.5cm\">Chaussure Femmes=EU:37=US:6.5</option>");
            sizestr.Append("<option value=\"Chaussure Femmes=EU:38=US:7.5=24cm\">Chaussure Femmes=EU:38=US:7.5</option>");
            sizestr.Append("<option value=\"Chaussure Femmes=EU:39=US:8.5=24.5cm\">Chaussure Femmes=EU:39=US:8.5</option>");
            sizestr.Append("<option value=\"Chaussure Femmes=EU:40=US:9=25cm\">Chaussure Femmes=EU:40=US:9</option>");
            sizestr.Append("<option value=\"Chaussure Femmes=EU:41=US:10=25.5cm\">Chaussure Femmes=EU:41=US:10</option>");
            sizestr.Append("<option value=\"Chaussure Femmes=EU:42=US:11=26cm\">Chaussure Femmes=EU:42=US:11</option>");
            sizestr.Append("<option value=\"Chaussure Hommes=EU:39=US:7=24.5cm\">Chaussure Hommes=EU:39=US:7</option>");
            sizestr.Append("<option value=\"Chaussure Hommes=EU:40=US:7.5=25cm\">Chaussure Hommes=EU:40=US:7.5</option>");
            sizestr.Append("<option value=\"Chaussure Hommes=EU:41=US:8=25.5cm\">Chaussure Hommes=EU:41=US:8</option>");
            sizestr.Append("<option value=\"Chaussure Hommes=EU:42=US:8.5=26cm\">Chaussure Hommes=EU:42=US:8.5</option>");
            sizestr.Append("<option value=\"Chaussure Hommes=EU:43=US:9=26.5cm\">Chaussure Hommes=EU:43=US:9</option>");
            sizestr.Append("<option value=\"Chaussure Hommes=EU:44=US:10=27cm\">Chaussure Hommes=EU:44=US:10</option>");
            sizestr.Append("<option value=\"Chaussure Hommes=EU:45=US:11=27.5cm\">Chaussure Hommes=EU:45=US:11</option>");
            sizestr.Append("<option value=\"Chaussure Hommes=EU:46=US:12=28cm\">Chaussure Hommes=EU:46=US:12</option>");
            sizestr.Append("<option value=\"Vetements=XS\">Vetements=XS</option>");
            sizestr.Append("<option value=\"Vetements=S\">Vetements=S</option>");
            sizestr.Append("<option value=\"Vetements=M\">Vetements=M</option>");
            sizestr.Append("<option value=\"Vetements=L\">Vetements=L</option>");
            sizestr.Append("<option value=\"Vetements=XL\">Vetements=XL</option>");
            sizestr.Append("<option value=\"Vetements=2XL\">Vetements=2XL</option>");
            sizestr.Append("<option value=\"Vetements=3XL\">Vetements=3XL</option>");
            sizestr.Append("<option value=\"Vetements=4XL\">Vetements=4XL</option>");
            sizestr.Append("<option value=\"Vetements=5XL\">Vetements=5XL</option>");


            sizestr.Append("<option value=\"Enfant:EUR35/US3\">Enfant:EUR35/US3</option>");
            sizestr.Append("<option value=\"Enfant:EUR34/US2.5\">Enfant:EUR34/US2.5</option>");
            sizestr.Append("<option value=\"Enfant:EUR33/US2\">Enfant:EUR33/US2</option>");
            sizestr.Append("<option value=\"Enfant:EUR32/US1.5\">Enfant:EUR32/US1.5</option>");
            sizestr.Append("<option value=\"Enfant:EUR31/US13\">Enfant:EUR31/US13</option>");
            sizestr.Append("<option value=\"Enfant:EUR30/US12.5\">Enfant:EUR30/US12.5</option>");
            sizestr.Append("<option value=\"Enfant:EUR29/US12\">Enfant:EUR29/US12</option>");
            sizestr.Append("<option value=\"Enfant:EUR28/US11\">Enfant:EUR28/US11</option>");
            sizestr.Append("</select>");
            Size = sizestr.ToString();
            int ccccc = 0;
            if (cid != 0)
            {
                ccccc = cid;
            }
            if (Request.QueryString["cid"] != null && Request.QueryString["cid"] != "")
            {
                ccccc = int.Parse(Request.QueryString["cid"]);
            }
            SqlParameter[] para = { new SqlParameter("@kcid", SqlDbType.Int) };
            para[0].Value = ccccc;
            DataSet dsos = GetDataSet("selectJC", para);
            if (access_sql.yzTable(dsos))
            {
                wdprice = dsos.Tables[0].Rows[0][0].ToString();
                wdgj = dsos.Tables[0].Rows[0][1].ToString();
            }
            if (Request.QueryString["gj"] != null)
            {
                wdgj = Request.QueryString["gj"];
            }
            int min = 50;
            int max = 90;
            if (wdprice != "" && wdprice.Contains("-"))
            {
                min = int.Parse(wdprice.Split('-')[0]);
                max = int.Parse(wdprice.Split('-')[1]);
            }

            if (wdprice != "" && wdprice.Contains("-"))
            {
                price = double.Parse(getprice(min, max) + ".99");
            }
            else
            {
                price = double.Parse(wdprice);
            }
            switch (wdgj)
            {
                case "pt":
                    curcode = "EUR";
                    curfh = "€";
                    Size = Size.Replace("Taille:", "Cortar:").Replace("Vetements", "Confecções").Replace("Chaussure Femmes", "Sapatos femininos").Replace("Chaussure Hommes", "Sapatos masculinos").Replace("Taille moyenne", "Altura média").Replace("Enfant", "Filho");
                    pxstring = "Classificação <span itemprop=\"ratingValue\">4." + star + "</span>/5  com base em <span itemprop=\"reviewCount\">" + rcount + "</span> comentários de clientes";
                    pricestring = "Preço: <span itemprop=\"priceCurrency\" content=\"" + curcode + "\">" + curfh + "</span><span itemprop=\"price\">" + price + "</span><br /><link itemprop=\"availability\" href=\"http://schema.org/InStock\" /><span style='color:26394c; font-size:14px'>em estoque</span>";
                    Quantity = "Montante:";
                    addtocart = "Adicionar ao carrinho";
                    sizetx = "Por favor escolha uma opção";
                    Quantitytx = "Por favor insira a quantidade";
                    prhead = "Revisão de produtos";
                    pdhead = "Descrição do Produto";
                    lihead = "você pode gostar";
                    qdbuton = "Fechar";
                    style = "Estilo";
                    home = "Casa";
                    AboutUS = "sobre nós";
                    ContactUs = "Contate-Nos";
                    Payment = "Forma de pagamento";
                    SC = "Como pedir";
                    BQ = "© 2019-2023 <a href='HHHHH'>BBBBB</a> Todos os direitos reservados";
                    url1 = ym + "/page.aspx?la=fr&type=1";
                    url2 = ym + "/page.aspx?la=fr&type=2";
                    url3 = ym + "/page.aspx?la=fr&type=3";
                    url4 = ym + "/page.aspx?la=fr&type=4";
                    IIF = "Informações sobre o item";
                    stt = "Insira palavras-chave para pesquisar";
                    sbb = "olhe para";
                    crt = "Avaliações de Clientes";
                    rname = "Nome completo";
                    rTitle = "O título";
                    rrv = "Valor de avaliação";
                    rt = "Tempo";
                    sbb2 = "Enviar";
                    lihead0 = "Clientes que viram este item também viram";
                    rcontent = "A descrição";
                    break;
                case "fr":
                    curcode = "EUR";
                    curfh = "€";
                    pxstring = "Note <span itemprop=\"ratingValue\">5." + star + "</span>/5  basé sur <span itemprop=\"reviewCount\">" + rcount + "</span> commentaires des internautes";
                    pricestring = "Prix: <span itemprop=\"priceCurrency\" content=\"" + curcode + "\">" + curfh + "</span><span itemprop=\"price\">" + price + "</span><br /><link itemprop=\"availability\" href=\"http://schema.org/InStock\" /><span style='color:26394c; font-size:14px'>En stock</span>";
                    Quantity = "Quantité:";
                    addtocart = "Ajouter au panier";
                    sizetx = "Veuillez choisir une option";
                    Quantitytx = "S'il vous plaît entrer la quantité";
                    prhead = "Critiques de produits";
                    pdhead = "Description du produit";
                    lihead = "Tu pourrais aussi aimer";
                    qdbuton = "Fermer";
                    style = "Style";
                    home = "Accueil";
                    AboutUS = "À propos de nous";
                    ContactUs = "Contactez nous";
                    Payment = "Paiement";
                    SC = "Comment Commander";
                    BQ = "© 2019-2023 <a href='HHHHH'>BBBBB</a> Tous droits réservés";
                    url1 = ym + "/page.aspx?la=fr&type=1";
                    url2 = ym + "/page.aspx?la=fr&type=2";
                    url3 = ym + "/page.aspx?la=fr&type=3";
                    url4 = ym + "/page.aspx?la=fr&type=4";
                    IIF = "Informations sur l'élément";
                    stt = "Veuillez saisir des mots clés pour rechercher";
                    sbb = "chercher";
                    crt = "Avis des clients";
                    rname = "Nom complet";
                    rTitle = "Le titre";
                    rrv = "Valeur d'évaluation";
                    rt = "Temps";
                    sbb2 = "Soumettre";
                    rcontent = "La description";
                    lihead0 = "Les clients ayant consulté cet article ont également consulté";
                    break;
                case "com":
                    curcode = "USD";
                    curfh = "$";
                    Size = Size.Replace("Taille:", "Size:").Replace("Vetements", "Clothing").Replace("Chaussure Femmes", "Women's shoes").Replace("Chaussure Hommes", "Men's shoes").Replace("Taille moyenne", "Average Size").Replace("Enfant", "Kids");
                    pxstring = "Rated <span itemprop=\"ratingValue\">5." + star + "</span>/5 based on <span itemprop=\"reviewCount\">" + rcount + "</span> customer reviews";
                    pricestring = "Price: <span itemprop=\"priceCurrency\" content=\"" + curcode + "\">" + curfh + "</span><span itemprop=\"price\">" + price + "</span><br /><link itemprop=\"availability\" href=\"http://schema.org/InStock\" /><span style='color:26394c; font-size:14px'>In stock</span>";
                    Quantity = "Quantity:";
                    addtocart = "Add To Cart";
                    sizetx = "Please Select option";
                    Quantitytx = "Please enter the quantity";
                    prhead = "Product reviews";
                    pdhead = "product description";
                    lihead = "You may also like";
                    lihead0 = "Customers who viewed this item also viewed";
                    qdbuton = "Close";
                    style = "Style";
                    break;
                case "co.uk":
                    curcode = "GPB";
                    curfh = "￡";
                    Size = Size.Replace("Taille:", "Size:").Replace("Vetements", "Clothing").Replace("Chaussure Femmes", "Women's shoes").Replace("Chaussure Hommes", "Men's shoes").Replace("Taille moyenne", "Average Size").Replace("Enfant", "Kids");
                    pxstring = "Rated <span itemprop=\"ratingValue\">5." + star + "</span>/5 based on <span itemprop=\"reviewCount\">" + rcount + "</span> customer reviews";
                    pricestring = "Price: <span itemprop=\"priceCurrency\" content=\"" + curcode + "\">" + curfh + "</span><span itemprop=\"price\">" + price + "</span><br /><link itemprop=\"availability\" href=\"http://schema.org/InStock\" /><span style='color:26394c; font-size:14px'>In stock</span>";
                    Quantity = "Quantity:";
                    addtocart = "Add To Cart";
                    sizetx = "Please Select option";
                    Quantitytx = "Please enter the quantity";
                    prhead = "Product reviews";
                    pdhead = "product description";
                    lihead = "You may also like";
                    qdbuton = "Close";
                    style = "Style";
                    lihead0 = "Customers who viewed this item also viewed";
                    break;
                case "it":
                    curcode = "EUR";
                    curfh = "€";
                    Size = Size.Replace("Taille:", "Taglia:").Replace("Vetements", "Abbigliamento").Replace("Chaussure Femmes", "Scarpe da donna").Replace("Chaussure Hommes", "Scarpe da uomo").Replace("Taille moyenne", "taglia media").Replace("Enfant", "BAMBINI");
                    pxstring = "Valutato <span itemprop=\"ratingValue\">5." + star + "</span>/5 basato su <span itemprop=\"reviewCount\">" + rcount + "</span> recensioni dei clienti";
                    pricestring = "Prezzo: <span itemprop=\"priceCurrency\" content=\"" + curcode + "\">" + curfh + "</span><span itemprop=\"price\">" + price + "</span><br /><link itemprop=\"availability\" href=\"http://schema.org/InStock\" /><span style='color:26394c; font-size:14px'>In magazzino</span>";
                    Quantity = "Quantità:";
                    addtocart = "Aggiungi al carrello";
                    sizetx = "Si prega di selezionare l'opzione";
                    Quantitytx = "Si prega di inserire la quantità";
                    prhead = "Recensioni di prodotti";
                    pdhead = "Descrizione del prodotto";
                    lihead = "Potrebbe piacerti anche";
                    qdbuton = "Vicino";
                    style = "Stile";
                    home = "Casa";
                    AboutUS = "Riguardo a noi";
                    ContactUs = "Contattaci";
                    Payment = "Pagamento";
                    SC = "Come ordinare";
                    BQ = "© 2019-2023 <a href='HHHHH'>BBBBB</a> Tutti i diritti riservati.";
                    url1 = ym + "/page.aspx?la=it&type=1";
                    url2 = ym + "/page.aspx?la=it&type=2";
                    url3 = ym + "/page.aspx?la=it&type=3";
                    url4 = ym + "/page.aspx?la=it&type=4";
                    IIF = "Informazioni sull'articolo";
                    stt = "Inserisci le parole chiave per la ricerca";
                    sbb = "ricerca";
                    crt = "recensioni dei clienti";
                    rname = "Nome e cognome";
                    rTitle = "Titolo";
                    rrv = "Valore di valutazione";
                    rt = "Tempo";
                    sbb2 = "Invia";
                    rcontent = "Descrizione";
                    lihead0 = "I clienti che hanno visualizzato questo articolo hanno visto anche";
                    break;
                case "es":
                    curcode = "EUR";
                    curfh = "€";
                    Size = Size.Replace("Taille:", "Tamaño:").Replace("Vetements", "Ropa").Replace("Chaussure Femmes", "Zapato de mujer").Replace("Chaussure Hommes", "Zapato de hombre").Replace("Taille moyenne", "Tamaño promedio").Replace("Enfant", "Niño");
                    pxstring = "Calificación <span itemprop=\"ratingValue\">5." + star + "</span>/5 basado en <span itemprop=\"reviewCount\">" + rcount + "</span> opiniones de clientes";
                    pricestring = "Precio: <span itemprop=\"priceCurrency\" content=\"" + curcode + "\">" + curfh + "</span><span itemprop=\"price\">" + price + "</span><br /><link itemprop=\"availability\" href=\"http://schema.org/InStock\" /><span style='color:26394c; font-size:14px'>En stock</span>";
                    Quantity = "Cantidad:";
                    addtocart = "Añadir a la cesta";
                    sizetx = "Seleccione la opción";
                    Quantitytx = "Por favor ingrese la cantidad";
                    prhead = "Revisiones de producto";
                    pdhead = "Descripción del producto";
                    lihead = "También te puede interesar";
                    qdbuton = "Cerrar";
                    style = "Estilo";
                    lihead0 = "Los clientes que vieron este artículo también vieron";
                    home = "Casa";
                    AboutUS = "Sobre nosotros";
                    ContactUs = "Contáctenos";
                    Payment = "Pago";
                    SC = "Como ordenar";
                    BQ = "© 2019-2023 <a href='HHHHH'>BBBBB</a> Todos los derechos reservados.";
                    url1 = ym + "/page.aspx?la=es&type=1";
                    url2 = ym + "/page.aspx?la=es&type=2";
                    url3 = ym + "/page.aspx?la=es&type=3";
                    url4 = ym + "/page.aspx?la=es&type=4";
                    IIF = "Información del artículo";
                    stt = "Por favor, introduzca palabras clave para buscar";
                    sbb = "buscar";
                    crt = "Valoración de los clientes";
                    rname = "Nombre completo";
                    rTitle = "Título";
                    rrv = "Valor de calificación";
                    rt = "Hora";
                    sbb2 = "Enviar";
                    rcontent = "Descripción";

                    break;
                case "de":
                    curcode = "EUR";
                    curfh = "€";
                    Size = Size.Replace("Taille:", "Größe:").Replace("Vetements", "Kleidung").Replace("Chaussure Femmes", "Damenschuh").Replace("Chaussure Hommes", "Herrenschuh").Replace("Taille moyenne", "Durchschnittsgröße").Replace("Enfant", "Kinder");
                    pxstring = "Bewertet <span itemprop=\"ratingValue\">5." + star + "</span>/5 basiert auf <span itemprop=\"reviewCount\">" + rcount + "</span> Kundenbewertungen";
                    pricestring = "Preis: <span itemprop=\"priceCurrency\" content=\"" + curcode + "\">" + curfh + "</span><span itemprop=\"price\">" + price + "</span><br /><link itemprop=\"availability\" href=\"http://schema.org/InStock\" /><span style='color:26394c; font-size:14px'>Auf Lager</span>";
                    Quantity = "Menge:";
                    addtocart = "In den Warenkorb";
                    sizetx = "Bitte wählen Sie eine Option";
                    Quantitytx = "Bitte geben Sie die Menge ein";
                    prhead = "Produktrezensionen";
                    pdhead = "Produktbeschreibung";
                    lihead = "Sie können auch mögen";
                    qdbuton = "Schließen";
                    style = "Stil";
                    home = "Zuhause";
                    AboutUS = "Über uns";
                    ContactUs = "Kontaktiere uns";
                    Payment = "Zahlung";
                    SC = "Wie bestellen?";
                    BQ = "© 2019-2023 <a href='HHHHH'>BBBBB</a> Alle Rechte vorbehalten.";
                    url1 = ym + "/page.aspx?la=de&type=1";
                    url2 = ym + "/page.aspx?la=de&type=2";
                    url3 = ym + "/page.aspx?la=de&type=3";
                    url4 = ym + "/page.aspx?la=de&type=4";
                    IIF = "Gegenstand Information";
                    stt = "Bitte geben Sie die zu suchenden Schlüsselwörter ein";
                    sbb = "Suche";
                    crt = "Kundenbewertungen";
                    rname = "Vollständiger Name";
                    rTitle = "Titel";
                    rrv = "Bewertungswert";
                    rt = "Zeit";
                    sbb2 = "einreichen";
                    rcontent = "Beschreibung";
                    lihead0 = "Kunden, die sich das angeschaut haben, schauten sich auch an";
                    break;
                case "nl":
                    curcode = "EUR";
                    curfh = "€";
                    Size = Size.Replace("Taille:", "afmeting:").Replace("Vetements", "kleding").Replace("Chaussure Femmes", "Damesschoen").Replace("Chaussure Hommes", "Herenschoen").Replace("Taille moyenne", "Gemiddelde grootte").Replace("Enfant", "Kinderen");
                    pxstring = "Beoordeeld <span itemprop=\"ratingValue\">5." + star + "</span>/5 gebaseerd op <span itemprop=\"reviewCount\">" + rcount + "</span> klanten beoordelingen";
                    pricestring = "prijs: <span itemprop=\"priceCurrency\" content=\"" + curcode + "\">" + curfh + "</span><span itemprop=\"price\">" + price + "</span><br /><link itemprop=\"availability\" href=\"http://schema.org/InStock\" /><span style='color:26394c; font-size:14px'>Op voorraad</span>";
                    Quantity = "lot:";
                    addtocart = "Voeg toe aan winkelwagen";
                    sizetx = "Kies een optie";
                    Quantitytx = "Vul alstublieft de hoeveelheid in";
                    prhead = "product Reviews";
                    pdhead = "product Beschrijving";
                    lihead = "Dit vind je misschien ook leuk";
                    qdbuton = "dicht";
                    style = "stijl";
                    home = "thuis";
                    AboutUS = "Over ons";
                    ContactUs = "Neem contact met ons";
                    Payment = "Betaling";
                    SC = "Hoe te bestellen";
                    BQ = "© 2019-2023 <a href='HHHHH'>BBBBB</a> Alle rechten voorbehouden.";
                    url1 = ym + "/page.aspx?la=de&type=1";
                    url2 = ym + "/page.aspx?la=de&type=2";
                    url3 = ym + "/page.aspx?la=de&type=3";
                    url4 = ym + "/page.aspx?la=de&type=4";
                    IIF = "onderwerp informatie";
                    stt = "Voer sleutelwoorden in om te zoeken";
                    sbb = "zoeken";
                    crt = "klanten-reviews";
                    rname = "Voor-en achternaam";
                    rTitle = "Titel";
                    rrv = "Rating Waarde";
                    rt = "Tijd";
                    sbb2 = "Verzenden";
                    rcontent = "Beschrijving";
                    lihead0 = "Klanten die dit item bekeken, bekeken ook";
                    break;
            }
        }
    }
    public void bindother()
    {

        //mpn = DateTime.Now.Month.ToString() + DateTime.Now.Hour.ToString();

    }
    public string la = "";
    public access_sql sql = new access_sql();
    public StringBuilder jslist = new StringBuilder();
    public int cid = 0;
    public string sku = "";
    public string othep = "";
    public void bindimgs()
    {
        if ((Request.QueryString["iid"] != null && Request.QueryString["iid"] != ""))
        {

            int iid = 0;
            if (Request.QueryString["iid"].Split('-').Length > 0)
            {
                iid = int.Parse(Request.QueryString["iid"].Split('-')[0]);
            }
            else
            {
                iid = int.Parse(Request.QueryString["iid"]);
            }
            displays.Visible = true;
            SqlParameter[] para ={
                                     new SqlParameter("@iid",SqlDbType.Int)};


            para[0].Value = iid;
            DataSet dsimgs = GetDataSet("selectAllbyIID", para);

            if (access_sql.yzTable(dsimgs))
            {
                keyword = HttpUtility.UrlDecode(dsimgs.Tables[0].Rows[0]["kname"].ToString());
                string skeyword = keyword;
                cid = int.Parse(dsimgs.Tables[0].Rows[0]["kcid"].ToString());
                mainimg = dsimgs.Tables[0].Select("iid=" + iid + "")[0]["iimg"].ToString();
                maintitle = dsimgs.Tables[0].Select("iid=" + iid + "")[0]["ititle"].ToString();
                sku = maintitle;
                allimgs = "<img style=\"width:80%\" src=\"" + mainimg + "\" alert=\"" + keyword + "\" title=\"" + maintitle + "\"/><br>" + maintitle + "<br>";
                if (dsimgs.Tables[0].Rows.Count > 10)
                {

                    int sl = getNum(1, 5, 8)[0];
                    int[] titless = getNum(sl, 0, dsimgs.Tables[0].Rows.Count - 1);
                    int[] imgss = getNum(sl, 0, dsimgs.Tables[0].Rows.Count - 1);
                    int[] namess = getNum(sl, 0, 250);
                    int[] ppppp = getNum(sl, 0, 12);
                    star = "0";
                    rcount = sl.ToString();
                    StringBuilder plstr = new StringBuilder();
                    for (int i = 0; i < sl; i++)
                    {
                        string rtime = DateTime.Now.AddHours(-(namess[i])).ToString("yyyy-MM-dd");
                        string rdis = dsimgs.Tables[0].Rows[titless[i]]["ititle"].ToString();
                        string rname_ = keyword;
                        rdis = rdis + " " + keyword;
                        //string[] sprdis = rdis.Split(' ');
                        //if (sprdis.Length > 0)
                        //{

                        //    int crwz = getNum(1, 0, sprdis.Length - 1)[0];
                        //    rname_ = sprdis[crwz];
                        //    for (int q = 0; q < sprdis.Length; q++)
                        //    {
                        //        if (q == crwz)
                        //        {
                        //            rdis += sprdis[q] + " " + "<strong>" + keyword + "</strong> ";
                        //        }
                        //        else
                        //        {
                        //            rdis += sprdis[q] + " ";
                        //        }
                        //    }
                        //}
                        string rimg = dsimgs.Tables[0].Rows[imgss[i]]["iimg"].ToString();
                        plstr.Append("<div itemprop=\"review\" itemtype=\"http://schema.org/Review\" itemscope>");
                        plstr.Append("<div class=\"rd\">");
                        plstr.Append("<div class=\"rt\" itemprop=\"author\" itemtype=\"http://schema.org/Person\" itemscope>");
                        plstr.Append("<span itemprop=\"name\">" + rrrname[namess[i]] + "</span>");
                        plstr.Append("</div>");
                        plstr.Append("<div class=\"rt\">");
                        plstr.Append("<span itemprop=\"datePublished\">" + rtime + "</span>&nbsp;&nbsp;<span>" + phones[ppppp[i]] + "</span>");
                        plstr.Append("</div>");
                        plstr.Append("</div>");
                        plstr.Append("<div class=\"rd\">");
                        plstr.Append("<span itemprop=\"description\">" + rdis + "</span>");
                        plstr.Append("</div>");
                        plstr.Append("<div class=\"rd\">");
                        plstr.Append("<span itemprop=\"name\">" + rname_ + "</span>");
                        plstr.Append("</div>");
                        plstr.Append("<div class=\"rd\">");
                        plstr.Append("<img style=\"width:300px\" itemprop=\"image\" src=\"" + rimg + "\" />");
                        plstr.Append("</div>");
                        plstr.Append("<div itemprop=\"reviewRating\" itemtype=\"http://schema.org/Rating\" itemscope>");
                        plstr.Append("<meta itemprop=\"ratingValue\" content=\"5\" />");
                        plstr.Append("<meta itemprop=\"bestRating\" content=\"5\" />");
                        plstr.Append("<meta itemprop=\"worstRating\" content=\"1\" />");
                        plstr.Append("</div>");
                        plstr.Append("</div>");
                    }
                    pl = plstr.ToString();

                    othep += "<ul>";
                    int dd = 0;
                    int lj = 0;
                    StringBuilder str = new System.Text.StringBuilder();
                    str.Append(" <dl class=\"clearfix iteminfo_parameter sys_item_specpara\" data-sid=\"0\">");
                    str.Append("<input type=\"hidden\" name=\"s0\" id=\"s0\" class='hse' vaule='" + 0 + "'>");
                    str.Append("<dd><ul class=\"sys_spec_img\">");
                    for (int i = 0; i < dsimgs.Tables[0].Rows.Count; i++)
                    {
                        DataRow dr = dsimgs.Tables[0].Rows[i];
                        bool f = false;
                        bool d = false;
                        if (((IList)imgss).Contains(i) || dr["iid"].ToString() == iid.ToString())
                        {
                            f = true;
                        }
                        if (dd >= 9) { d = true; }
                        if (!f && !d)
                        {
                            dd++;
                            string key = dr["kname"].ToString();
                            string img = dr["iimg"].ToString();
                            string title = dr["ititle"].ToString();
                            string url = "UUUUU" + "?iid=" + dr["iid"].ToString() + "-" + HttpUtility.UrlEncode(key) + "&cid=" + cid;
                            othep += "<li><div class='iimg'><a href=\"" + url + "\"><img style='max-height:100px' src=\"" + img + "\" alt=\"" + keyword + "\" title=\"" + title + "\" /></a></div><div  class='ititle'><a href=\"" + url + "\">" + title + "</a></div></li>";
                        }
                        if (!f && d)
                        {
                            string img = dr["iimg"].ToString();
                            string title = dr["ititle"].ToString();
                            str.Append("<li data-aid=\"" + lj + "\" data-title=\"" + title + "\" " + (lj == 0 ? "class=\"selected\"" : "") + "  ><a href=\"javascript:;\" style=\"background:url(" + img + ") center no-repeat; background-size: 50px, 50px \"  title=\"" + title + "\" ><span>" + title + "</span></a><i></i></li>");
                            allimgs += ("  <img itemprop=\"image\" src=\"" + img + "\" alt=\"" + keyword + "\" />" + "\n" + "<span>" + title + "</span>");
                            lj++;
                        }
                    }
                    Allimgs = str.Append("</ul></dd></dl>").ToString();
                    othep += "</ul>";
                }


            }
        }
        else
        {
            if ((Request.QueryString["cid"] != null && Request.QueryString["cid"] != ""))
            {
                int zs = 0;
                int allpnum = 0;
                DataSet dsallkeys = new DataSet();
                indexdisplay.Visible = true;
                string sqlstr = "";
                if (Request.QueryString["searchtxt"] != null)
                {

                    SqlParameter[] para ={
                                     new SqlParameter("@kname",SqlDbType.NVarChar),
                                     new SqlParameter("@kcid",SqlDbType.Int)};


                    para[0].Value = HttpUtility.UrlDecode(Request.QueryString["searchtxt"]);
                    para[1].Value = int.Parse(Request.QueryString["cid"]);
                    dsallkeys = GetDataSet("searchbytxt_FristImg", para);
                    zs = dsallkeys.Tables[0].Rows.Count;

                }
                else
                {
                    SqlParameter[] para ={
                                     new SqlParameter("@pageSize",SqlDbType.Int),
                                     new SqlParameter("@pageIndex",SqlDbType.Int),
                                      new SqlParameter("@pageCount",SqlDbType.Int),
                                       new SqlParameter("@recodNumber",SqlDbType.Int),
                                     new SqlParameter("@kcid",SqlDbType.Int)};

                    int pnum = 1;
                    if (Request.QueryString["pnum"] != null)
                    {
                        try
                        {
                            pnum = int.Parse(Request.QueryString["pnum"]);
                        }
                        catch
                        {

                        }
                    }
                    para[0].Value = 100;
                    para[1].Value = pnum;
                    para[2].Direction = ParameterDirection.Output;
                    para[3].Direction = ParameterDirection.Output;
                    para[4].Value = int.Parse(Request.QueryString["cid"]);
                    dsallkeys = GetDataSet("JD_pagelist_FristImg", para);
                    if (para[2].Value != null && para[3].Value != null)
                    {
                        zs = int.Parse(para[2].Value.ToString());
                        allpnum = int.Parse(para[3].Value.ToString());
                    }
                }
                if (access_sql.yzTable(dsallkeys))
                {


                    int min = 50;
                    int max = 90;
                    if (wdprice != "" && wdprice.Contains("-"))
                    {
                        min = int.Parse(wdprice.Split('-')[0]);
                        max = int.Parse(wdprice.Split('-')[1]);
                    }
                    string xi = "0";
                    string xc = "10";

                    string txturl = Request.QueryString["txt"];
                    string txtcon = "";
                    int cs = 0;



                    cs++;
                    string pl = Request.QueryString["pl"];
                    string you = Request.QueryString["you"];
                    StringBuilder str = new StringBuilder();
                    jslist.Append("<script type=\"application/ld+json\">");
                    jslist.Append("{");
                    jslist.Append("\"@context\": \"http://schema.org/\",");
                    jslist.Append("\"@type\": \"ItemList\",");
                    jslist.Append("\"mainEntityOfPage\": {");
                    jslist.Append("\"@type\": \"CollectionPage\",");
                    jslist.Append("\"@id\": \"UUUUU\"},");
                    jslist.Append("\"itemListElement\": [");
                    str.Append("<div class=\"di\" style=\"width: 100%;float: left;\"><ul>");
                    DataTable dtt = SJDataTable(dsallkeys.Tables[0]);
                    for (int i = 0; i < dtt.Rows.Count; i++)
                    {


                        string key = dtt.Rows[i]["kname"].ToString();
                        string img = dtt.Rows[i]["iimg"].ToString();
                        string url = "UUUUU" + "?iid=" + dtt.Rows[i]["iid"].ToString() + "-" + HttpUtility.UrlEncode(key) + "&cid=" + Request.QueryString["cid"];
                        str.Append("<li style='width: 25%;float: left;    list-style: none;text-align: center;'><div>");
                        str.Append("<a href=\"" + url + "\"><img src=\"" + img + "\" style=\"width:150px\"></a></div><div>");
                        str.Append("<a href=\"" + url + "\">" + key + "</a></div></li>");
                        if (i != dtt.Rows.Count - 1)
                        {
                            jslist.Append("{\"@type\": \"ListItem\",\"position\": " + (i + 1) + ",\"url\": \"" + url + "\"}, ");
                        }
                        else
                        {
                            jslist.Append("{\"@type\": \"ListItem\",\"position\": " + (i + 1) + ",\"url\": \"" + url + "\"}");
                        }

                    }
                    jslist.Append("],\"numberOfItems\": " + dtt.Rows.Count + "}</script>");
                    jslist.Append("<script type=\"application/ld+json\">");
                    jslist.Append("{\"@context\": \"http://schema.org/\",\"@type\": \"Person\",\"name\": \"NNNNN\",\"description\": \"SSSSS\",\"url\": \"UUUUU\"}");
                    jslist.Append("</script>");
                    str.Append("</ul></div>");
                    str.Append("<div style='width: 100%;float: left;'><ul style='width: 100%;float: left;'>");
                    for (int i = 1; i <= allpnum; i++)
                    {
                        str.Append("<li style='float: left;list-style: none;width:2%'> <a href=\"UUUUU?cid=" + Request.QueryString["cid"] + "&pnum=" + i + "\" >" + i + "</a></li>");
                    }
                    str.Append("</ul></div>");
                    index_xs = str.ToString();



                }
            }
        }
    }
    public DataTable SJDataTable(DataTable dtTemplate)
    {
        dtTemplate.Columns.Add("ID");
        foreach (DataRow item in dtTemplate.Rows)
        {
            item["id"] = Guid.NewGuid().ToString();
        }
        DataView dv = new DataView(dtTemplate);
        dv.Sort = " id";
        return dv.ToTable();
    }

    public static DataSet GetDataSet(string cmdText, params SqlParameter[] ps)
    {
        DataSet ds = new DataSet();
        try
        {
            using (SqlDataAdapter sda = new SqlDataAdapter(cmdText, ConfigurationSettings.AppSettings["SQLConnectionString"]))
            {
                if (ps != null)
                {
                    sda.SelectCommand.Parameters.AddRange(ps);
                }
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sda.Fill(ds);
            }
            return ds;
        }
        catch (Exception ex)
        {
            ds.Dispose();
            throw (ex);
        }
    }

    private DataTable GetDistinctTable(DataSet ds, string colName)
    {

        DataTable dtn = new DataTable();
        dtn.Columns.Add("kname");
        foreach (DataRow item in ds.Tables[0].Rows)
        {
            if (dtn.Select("kname='" + item["" + colName + ""].ToString().Replace("'", "''") + "'").Length == 0)
            {
                dtn.Rows.Add(new object[] { item[colName] });
            }
        }
        return dtn;

    }
    public string getprice(int min, int max)
    {
        string ru = "";
        var r = new Random(Guid.NewGuid().GetHashCode());
        ru = r.Next(min, max).ToString(); ;

        return ru;
    }
    public void bindpl()
    {
        if (Request.QueryString["pl"] != null && Request.QueryString["pl"] != "")
        {

            if (Request.QueryString["pl"] == "fr")
            {
                bindfrpl();
            }
            else if (Request.QueryString["pl"] == "en")
            {
                bindenpl();
            }
        }
    }

    public DataSet GreatDs(string sql, string c)
    {
        DataSet ds = new DataSet();
        OleDbConnection conn = new OleDbConnection();//创建连接对象
        conn.ConnectionString = c;//给连接字符串赋值
        conn.Open();//打开数据库
        try
        {
            OleDbDataAdapter Dar = new OleDbDataAdapter(sql, conn);
            Dar.Fill(ds);
        }
        catch
        {

        }
        finally
        {
            conn.Close();
        }
        return ds;
    }
    public void bindfrpl()
    {
        try
        {


            string q = "20";
            if (Request.QueryString["q"] != null)
            {
                q = Request.QueryString["q"];
            }
            string conn = "";
            List<string> li = new List<string>();

            Random random = new Random(Guid.NewGuid().GetHashCode());
            int r = random.Next();
            int cs = 0;
            do
            {
                cs++;
                string id = GreatDs("select top 1 PID from CJ order By Rnd(" + (-r) + "*id)", "Provider=Microsoft.Ace.OleDb.12.0;Data Source=" + HttpContext.Current.Server.MapPath("/") + "/IDSFR1.mdb;Persist Security Info=False;").Tables[0].Rows[0][0].ToString();
                string url = "https://api.bazaarvoice.com/data/batch.json?" + "passkey=lh0v6yyhp8hl5egy9822mebmh&apiversion=5.5&displaycode=13526-fr_fr&resource.q0=products&filter.q0=id:eq:" + id + "&stats.q0=reviews&filteredstats.q0=reviews&filter_reviews.q0=contentlocale:eq:fr_BE,fr_CH,fr_FR&filter_reviewcomments.q0=contentlocale:eq:fr_BE,fr_CH,fr_FR&resource.q1=reviews&filter.q1=isratingsonly:eq:false&filter.q1=productid:eq:" + id + "&filter.q1=contentlocale:eq:fr_BE,fr_CH,fr_FR&sort.q1=relevancy:a1&stats.q1=reviews&filteredstats.q1=reviews&include.q1=authors,products,comments&filter_reviews.q1=contentlocale:eq:fr_BE,fr_CH,fr_FR&filter_reviewcomments.q1=contentlocale:eq:fr_BE,fr_CH,fr_FR&filter_comments.q1=contentlocale:eq:fr_BE,fr_CH,fr_FR&limit.q1=" + q + "&offset.q1=0";
                conn = HttpPost(url);
            } while (conn == "" && cs < 5);

            conn = conn.Replace("\"CID\":\"", "镍").Replace("Videos", "奋");
            li = GetValue(conn, "镍", "奋");
            StringBuilder str = new System.Text.StringBuilder();
            if (li.Count > 0)
            {
                foreach (string item in li)
                {
                    try
                    {


                        string time = "";
                        string title = "";
                        string name = "";
                        string content = "";
                        string star = "";
                        string temp = item;
                        if (temp.Contains("LastModeratedTime\":\""))
                        {
                            string temp_ = temp.Replace("LastModeratedTime\":\"", "镍").Split('镍')[1];
                            time = temp_.Substring(0, temp_.IndexOf(".")).Replace("T", " ").Replace("\r", "").Replace("\n", "");
                        }
                        if (temp.Contains("\"Title\":\""))
                        {
                            string temp_ = temp.Replace("\"Title\":\"", "镍").Split('镍')[1];
                            title = temp_.Substring(0, temp_.IndexOf("\"")).Replace("\r", "").Replace("\n", "");
                        }
                        if (temp.Contains("\"UserNickname\":\""))
                        {
                            string temp_ = temp.Replace("\"UserNickname\":\"", "镍").Split('镍')[1];
                            name = temp_.Substring(0, temp_.IndexOf("\"")).Replace("\r", "").Replace("\n", "");
                        }
                        if (temp.Contains("\"ReviewText\":\""))
                        {
                            string temp_ = temp.Replace("\"ReviewText\":\"", "镍").Replace("\"Title\"", "镍").Replace("\"UserNickname\"", "镍").Split('镍')[1];
                            content = temp_.Replace("\",", "").Replace("\r", "").Replace("\n", "");
                        }
                        if (temp.Contains("\"Rating\":"))
                        {
                            string temp_ = temp.Replace("\"Rating\":", "镍").Split('镍')[1];
                            star = temp_.Substring(0, temp_.IndexOf(","));
                        }

                        str.Append("<div itemprop=\"review\" itemscope itemtype=\"http://schema.org/Review\">" + "\n");
                        str.Append("<span itemprop=\"name\">" + Unicode2String(title) + "</span> -" + "\n");
                        str.Append("by <span itemprop=\"author\">" + Unicode2String(name) + "</span>," + "\n");
                        str.Append("<meta itemprop=\"datePublished\" content=\"" + time + "\">" + time + "" + "\n");
                        str.Append("<div itemprop=\"reviewRating\" itemscope itemtype=\"http://schema.org/Rating\">" + "\n");
                        str.Append("<meta itemprop=\"worstRating\" content = \"1\"/>" + "\n");
                        str.Append("<span itemprop=\"ratingValue\">" + star + "</span>/" + "\n");
                        str.Append("<span itemprop=\"bestRating\">5</span>stars" + "\n");
                        str.Append("</div>");
                        str.Append("<div itemprop=\"description\">" + Unicode2String(content) + "</div>" + "\n");
                        str.Append("</div>" + "\n");
                    }
                    catch
                    {

                        throw;
                    }
                }
                pl = str.ToString();
            }

        }
        catch
        {


        }
    }
    public void bindenpl()
    {
        try
        {


            string q = "20";
            if (Request.QueryString["q"] != null)
            {
                q = Request.QueryString["q"];
            }
            string conn = "";
            List<string> li = new List<string>();

            Random random = new Random(Guid.NewGuid().GetHashCode());
            int r = random.Next();
            int cs = 0;
            do
            {
                string id = GreatDs("select top 1 PID from CJ order By Rnd(" + (-r) + "*id)", "Provider=Microsoft.Ace.OleDb.12.0;Data Source=" + HttpContext.Current.Server.MapPath("/") + "/IDS1.mdb;Persist Security Info=False;").Tables[0].Rows[0][0].ToString();
                string url = "https://api.bazaarvoice.com/data/batch.json?" + "passkey=caPCsWJ9PpBOzvyJB7i1KVeIm0fHAOleTos4OW4jYMbKw&apiversion=5.5&displaycode=13107-en_us&resource.q0=products&filter.q0=id:eq:" + id + "&stats.q0=reviews&filteredstats.q0=reviews&filter_reviews.q0=contentlocale:eq:en*,en_US&filter_reviewcomments.q0=contentlocale:eq:en*,en_US&resource.q1=reviews&filter.q1=isratingsonly:eq:false&filter.q1=productid:eq:" + id + "&filter.q1=contentlocale:eq:en*,en_US&sort.q1=relevancy:a1&stats.q1=reviews&filteredstats.q1=reviews&include.q1=authors,products,comments&filter_reviews.q1=contentlocale:eq:en*,en_US&filter_reviewcomments.q1=contentlocale:eq:en*,en_US&filter_comments.q1=contentlocale:eq:en*,en_US&limit.q1=" + q + "&offset.q1=0";
                conn = HttpPost(url);
                cs++;
            } while (conn == "" && cs < 5);

            conn = conn.Replace("\"CID\":\"", "镍").Replace("Videos", "奋");
            li = GetValue(conn, "镍", "奋");
            StringBuilder str = new System.Text.StringBuilder();
            if (li.Count > 0)
            {
                foreach (string item in li)
                {
                    try
                    {


                        string time = "";
                        string title = "";
                        string name = "";
                        string content = "";
                        string star = "";
                        string temp = item;
                        if (temp.Contains("LastModeratedTime\":\""))
                        {
                            string temp_ = temp.Replace("LastModeratedTime\":\"", "镍").Split('镍')[1];
                            time = temp_.Substring(0, temp_.IndexOf(".")).Replace("T", " ").Replace("\r", "").Replace("\n", "");
                        }
                        if (temp.Contains("\"Title\":\""))
                        {
                            string temp_ = temp.Replace("\"Title\":\"", "镍").Split('镍')[1];
                            title = temp_.Substring(0, temp_.IndexOf("\"")).Replace("\r", "").Replace("\n", "");
                        }
                        if (temp.Contains("\"UserNickname\":\""))
                        {
                            string temp_ = temp.Replace("\"UserNickname\":\"", "镍").Split('镍')[1];
                            name = temp_.Substring(0, temp_.IndexOf("\"")).Replace("\r", "").Replace("\n", "");
                        }
                        if (temp.Contains("\"ReviewText\":\""))
                        {
                            string temp_ = temp.Replace("\"ReviewText\":\"", "镍").Replace("\"Title\"", "镍").Replace("\"UserNickname\"", "镍").Split('镍')[1];
                            content = temp_.Replace("\",", "").Replace("\r", "").Replace("\n", "");
                        }
                        if (temp.Contains("\"Rating\":"))
                        {
                            string temp_ = temp.Replace("\"Rating\":", "镍").Split('镍')[1];
                            star = temp_.Substring(0, temp_.IndexOf(","));
                        }

                        str.Append("<div itemprop=\"review\" itemscope itemtype=\"http://schema.org/Review\">" + "\n");
                        str.Append("<span itemprop=\"name\">" + Unicode2String(title) + "</span> -" + "\n");
                        str.Append("by <span itemprop=\"author\">" + Unicode2String(name) + "</span>," + "\n");
                        str.Append("<meta itemprop=\"datePublished\" content=\"" + time + "\">" + time + "" + "\n");
                        str.Append("<div itemprop=\"reviewRating\" itemscope itemtype=\"http://schema.org/Rating\">" + "\n");
                        str.Append("<meta itemprop=\"worstRating\" content = \"1\"/>" + "\n");
                        str.Append("<span itemprop=\"ratingValue\">" + star + "</span>/" + "\n");
                        str.Append("<span itemprop=\"bestRating\">5</span>stars" + "\n");
                        str.Append("</div>");
                        str.Append("<div itemprop=\"description\">" + Unicode2String(content) + "</div>" + "\n");
                        str.Append("</div>" + "\n");
                    }
                    catch
                    {

                        throw;
                    }
                }
                pl = str.ToString();
            }


        }
        catch
        {


        }
    }
    public void bindyoutube()
    {
        if ((Request.QueryString["yt"] != null && Request.QueryString["yt"] != "") && (Request.QueryString["you"] != null && Request.QueryString["you"] == "1"))
        {
            string yurl = Request.QueryString["yt"];
            string videoId = "";
            string ru = "";
            ru = new System.Net.WebClient().DownloadString(yurl);

            string[] kkkk = keyword.ToLower().Split(' ');
            if (ru != "" && ru.Length > 100)
            {
                string[] sz = ru.Replace("\r\n", "镍").Split(new char[1] { '镍' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var s in sz)
                {
                    bool zd = false;
                    foreach (var ie in kkkk)
                    {
                        if (s.Split('|')[0].ToLower() == ie)
                        {
                            videoId = s;
                            zd = true;
                            break;
                        }
                    }
                    if (zd)
                    {
                        break;
                    }

                }
                if (videoId == "")
                {
                    videoId = sz[int.Parse(getprice(0, sz.Length - 1))];
                }
            }


            if (videoId != "")
            {
                if (videoId.Contains("|"))
                {
                    videoId = videoId.Split('|')[1];

                    youtube = "<embed src=\"http://www.youtube.com/v/" + videoId + "\" title=\"" + Request.QueryString["shop"] + "\" type=\"application/x-shockwave-flash\" wmode=\"transparent\"  class='yt'></embed>";
                }
            }
        }
    }
    public string ms = "";
    public void bindMS()
    {
        try
        {
            if ((Request.QueryString["mt"] != null && Request.QueryString["mt"] != ""))
            {
                string yurl = Request.QueryString["mt"];
                string ru = "";
                ru = HttpGetNoDL(yurl);
                if (ru != "" && ru.Length > 800)
                {
                    string[] sz = ru.Replace("\r\n", "镍").Split(new char[1] { '镍' }, StringSplitOptions.RemoveEmptyEntries);
                    int[] wz = getNum(4, 0, sz.Length - 1);
                    ms += "<p>";
                    foreach (int i in wz)
                    {
                        ms += " " + sz[i] + " <strong>" + keyword + "</strong>";
                    }
                    ms += "</p>";
                }

            }
        }
        catch
        {


        }
    }
    public string SJ = "";
    public void bindSJ()
    {
        if ((cid != 0))
        {
            SqlParameter[] para ={
                                     new SqlParameter("@kcid",SqlDbType.Int),
                                     new SqlParameter("@minid",SqlDbType.Int),
                                      new SqlParameter("@maxid",SqlDbType.Int)};

            para[0].Value = cid;
            para[1].Direction = ParameterDirection.Output;
            para[2].Direction = ParameterDirection.Output;
            GetDataSet("P_selectMinMaxID", para);

            if (para[1].Value != null && para[1].Value.ToString() != "" && para[2].Value != null && para[2].Value.ToString() != "")
            {
                int min1 = int.Parse(para[1].Value.ToString());
                int max1 = int.Parse(para[2].Value.ToString());
                int[] sz = getNum(9, min1, max1);
                string kinstr = "";
                for (int i = 0; i < sz.Length; i++)
                {
                    kinstr += sz[i] + ",";
                }
                kinstr = kinstr.Substring(0, kinstr.Length - 1);
                kinstr += "";

                SqlParameter[] para2 ={
                                     new SqlParameter("@top",SqlDbType.Int),
                                     new SqlParameter("@kcid",SqlDbType.Int),
                                      new SqlParameter("@kinstr",SqlDbType.NVarChar)};

                para2[0].Value = 9;
                para2[1].Value = cid;
                para2[2].Value = kinstr;
                DataSet ds = GetDataSet("sjfristimg", para2);

                if (access_sql.yzTable(ds))
                {




                    SJ += "<ul>";
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {



                        string key = dr["kname"].ToString();
                        string img = dr["iimg"].ToString();
                        string title = dr["ititle"].ToString();
                        string url = "UUUUU" + "?iid=" + dr["iid"].ToString() + "-" + HttpUtility.UrlEncode(key) + "&cid=" + cid;
                        SJ += "<li><div class='iimg'><a href=\"" + url + "\"><img style='max-height:100px' src=\"" + img + "\" alt=\"" + keyword + "\" title=\"" + title + "\" /></a></div><div  class='ititle'><a href=\"" + url + "\">" + title + "</a></div></li>";

                    }
                    SJ += "</ul>";


                }
            }
        }
    }
    public int[] GetRandomUnrepeatArray(int minValue, int maxValue, int count)
    {
        Random rnd = new Random();
        int length = maxValue - minValue + 1;
        byte[] keys = new byte[length];
        rnd.NextBytes(keys);
        int[] items = new int[length];
        for (int i = 0; i < length; i++)
        {
            items[i] = i + minValue;
        }
        Array.Sort(keys, items);
        int[] result = new int[count];
        Array.Copy(items, result, count);
        return result;
    }

    public string gj = "";
    public string allimgs = "";
    public void zq(string con)
    {
        StringBuilder str = new StringBuilder();
        StringBuilder astr = new StringBuilder();
        con = con.Replace(",null,0,null,false]", "镍").Replace("\"\",\"\",\"\",1,[]", "镍").Split('镍')[1];


        List<string> li = new List<string>();

        string[] sssss = con.Replace("[1,[0,\"", "镍").Split('镍');
        int s = 0;
        int m = 39;
        if (Request.QueryString["xi"] != null && Request.QueryString["xc"] != null)
        {
            s = int.Parse(Request.QueryString["xi"]);
            m = int.Parse(Request.QueryString["xc"]) + 1;
        }
        if (m > sssss.Length - 1)
        {
            m = sssss.Length - 1;
        }

        for (int i = s + 1; i < m + 2; i++)
        {
            li.Add(sssss[i]);
        }

        if (li.Count > 0)
        {
            str.Append(" <dl class=\"clearfix iteminfo_parameter sys_item_specpara\" data-sid=\"0\">");
            str.Append("<input type=\"hidden\" name=\"s0\" id=\"s0\" class='hse' vaule='" + s + "'>");
            str.Append("<dd><ul class=\"sys_spec_img\">");
            string maintitle = "";
            for (int i = 0; i < li.Count; i++)
            {

                string img = "";
                string title = "";
                string jsdiv = li[i].Replace("\r", "").Replace("\n", "");



                if (jsdiv != "")
                {
                    try
                    {

                        string[] imgs = jsdiv.Replace(",[\"", "镍").Split('镍');
                        if (imgs.Length > 2)
                        {
                            img = imgs[2];

                            if (img != "")
                            {

                                img = img.Substring(0, img.IndexOf("\""));
                                if (img.Contains("?"))
                                {
                                    img = img.Split('?')[0];
                                }
                            }
                        }
                        string[] titles = jsdiv.Replace("\"2008\":[null,\"", "镍").Split('镍');
                        if (titles.Length > 1)
                        {
                            title = titles[1];
                            if (title != "")
                            {

                                title = title.Substring(0, title.IndexOf("\""));
                                title = title.Replace("...", "");

                            }
                        }

                    }
                    catch
                    {


                    }
                }


                if (img != "" && title != "")
                {
                    if (i == s)
                    {
                        str.Append("<li data-aid=\"" + i + "\" data-title=\"" + title + "\" class=\"selected\" ><a href=\"javascript:;\" style=\"background:url(" + img + ") center no-repeat; background-size: 50px, 50px \"  title=\"" + title + "\" ><span>" + title + "</span></a><i></i></li>");
                        mainimg = img;
                        maintitle = title;
                        astr.Append("  <img itemprop=\"image\" src=\"" + img + "\" alt=\"" + keyword + "\" />" + "\n" + "<span>" + title + "</span>");
                    }
                    else
                    {
                        str.Append("<li data-aid=\"" + i + "\" data-title=\"" + title + "\" ><a href=\"javascript:;\" style=\"background:url(" + img + ") center no-repeat; background-size: 50px, 50px \"  title=\"" + title + "\" ><span>" + title + "</span></a><i></i></li>");
                        astr.Append("  <img itemprop=\"image\" src=\"" + img + "\" alt=\"" + keyword + "\" />" + "\n" + "<span>" + title + "</span>");
                    }


                }

            }
            Allimgs = str.Append("</ul></dd></dl>").ToString();
            allimgs = astr.ToString();

        }

    }
    internal static string Unicode2String(string source)
    {
        return new Regex(@"\\u([0-9A-F]{4})", RegexOptions.IgnoreCase | RegexOptions.Compiled).Replace(source, x => Convert.ToChar(Convert.ToUInt16(x.Result("$1"), 16)).ToString());
    }
    public string xs = "";
    public string pl = "";
    private string GetResponseBody(HttpWebResponse response)
    {
        string responseBody = string.Empty;
        if (response.ContentEncoding.ToLower().Contains("gzip"))
        {
            using (GZipStream stream = new GZipStream(response.GetResponseStream(), CompressionMode.Decompress))
            {
                using (StreamReader reader = new StreamReader(stream))
                {
                    responseBody = reader.ReadToEnd();
                }
            }
        }
        else if (response.ContentEncoding.ToLower().Contains("deflate"))
        {
            using (DeflateStream stream = new DeflateStream(
                response.GetResponseStream(), CompressionMode.Decompress))
            {
                using (StreamReader reader =
                    new StreamReader(stream, Encoding.UTF8))
                {
                    responseBody = reader.ReadToEnd();
                }
            }
        }
        else
        {
            using (Stream stream = response.GetResponseStream())
            {
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    responseBody = reader.ReadToEnd();
                }
            }
        }
        return responseBody;
    }
    public string HttpGetJD(string url)
    {
        string ru = "";
        int cs = 0;

        cs++;
        try
        {
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                if (!url.Contains("https") && !url.Contains("http"))
                {
                    url = "https:" + url;
                }
                System.GC.Collect();
                System.Net.ServicePointManager.DefaultConnectionLimit = 512;
                request = (HttpWebRequest)WebRequest.Create(url);

                request.UserAgent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36";
                request.Method = "GET";
                request.Headers.Add("Accept-Encoding", "gzip, deflate");
                request.ServicePoint.Expect100Continue = false;
                request.ServicePoint.UseNagleAlgorithm = false;
                request.AllowWriteStreamBuffering = false;
                request.ServicePoint.ConnectionLimit = 65500;
                request.ContentType = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
                //request.Headers.Add("Accept-Language", la.Replace("_", "-"));

                request.Timeout = 20000;
                response = (HttpWebResponse)request.GetResponse();
                ru = GetResponseBody(response);

            }
            catch (Exception ex)
            {

                ru = ex.ToString();
                ru += request.Referer;
            }
            finally
            {

                if (response != null)
                {
                    response.Close();
                }
                if (request != null)
                {
                    request.Abort();
                }
            }
        }
        catch
        {


            ru = "";
        }

        return ru;
    }
    public string HttpGetGoogle(string url)
    {
        string ru = "";
        try
        {
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                if (!url.Contains("https") && !url.Contains("http"))
                {
                    url = "https:" + url;
                }
                System.GC.Collect();
                System.Net.ServicePointManager.DefaultConnectionLimit = 512;
                request = (HttpWebRequest)WebRequest.Create(url);
                request.Headers.Add("Accept-Encoding", "gzip, deflate");
                request.UserAgent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36"; ;
                request.Method = "GET";

                request.ServicePoint.Expect100Continue = false;
                request.ServicePoint.UseNagleAlgorithm = false;
                request.AllowWriteStreamBuffering = false;
                request.ServicePoint.ConnectionLimit = 65500;
                request.ContentType = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
                request.Headers.Add("Accept-Language", la.Replace("_", "-"));
                request.Timeout = 20000;
                response = (HttpWebResponse)request.GetResponse();
                ru = GetResponseBody(response);

            }
            catch (Exception ex)
            {

                ru = ex.ToString();
                ru += request.Referer;
            }
            finally
            {

                if (response != null)
                {
                    response.Close();
                }
                if (request != null)
                {
                    request.Abort();
                }
            }
        }
        catch
        {


            ru = "";
        }

        return ru;
    }
    public string HttpGetIndex(string url)
    {
        string ru = "";
        int cs = 0;
        do
        {
            cs++;
            try
            {
                HttpWebRequest request = null;
                HttpWebResponse response = null;
                try
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                    if (!url.Contains("https") && !url.Contains("http"))
                    {
                        url = "https:" + url;
                    }
                    //System.GC.Collect();
                    //System.Net.ServicePointManager.DefaultConnectionLimit = 512;
                    request = (HttpWebRequest)WebRequest.Create(url);

                    request.UserAgent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36";
                    request.Method = "GET";
                    //request.ServicePoint.Expect100Continue = false;
                    //request.ServicePoint.UseNagleAlgorithm = false;
                    //request.AllowWriteStreamBuffering = false;
                    //request.ServicePoint.ConnectionLimit = 65500;
                    request.ContentType = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
                    //request.Headers.Add("Accept-Language", Request.QueryString["hl"]);
                    //request.Headers.Add("Accept-Encoding", "gzip");
                    request.Timeout = 10000;
                    response = (HttpWebResponse)request.GetResponse();
                    ru = GetResponseBody(response);

                }
                catch
                {
                    ru = "";
                }
                finally
                {

                    if (response != null)
                    {
                        response.Close();
                    }
                    if (request != null)
                    {
                        request.Abort();
                    }
                }
            }
            catch
            {


                ru = "";
            }
        } while (ru.Length < 5000 && cs < 3);
        return ru;
    }
    public string HttpGetNoDL(string url)
    {
        string ru = "";
        int cs = 0;
        do
        {
            cs++;
            try
            {
                HttpWebRequest request = null;
                HttpWebResponse response = null;
                try
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                    if (!url.Contains("https") && !url.Contains("http"))
                    {
                        url = "https:" + url;
                    }
                    //System.GC.Collect();
                    //System.Net.ServicePointManager.DefaultConnectionLimit = 512;
                    request = (HttpWebRequest)WebRequest.Create(url);
                    //  string[] allbr = File.ReadAllText(Server.MapPath("br.txt"), Encoding.UTF8).Split('|');
                    //string br = allbr[int.Parse(getprice(0, allbr.Length - 1))];
                    request.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36";
                    request.Method = "GET";

                    //request.ServicePoint.Expect100Continue = false;
                    //request.ServicePoint.UseNagleAlgorithm = false;
                    //request.AllowWriteStreamBuffering = false;
                    //request.ServicePoint.ConnectionLimit = 65500;
                    request.ContentType = "text/html";
                    //request.Headers.Add("Accept-Language", Request.QueryString["hl"]);
                    //request.Headers.Add("Accept-Encoding", "gzip");
                    request.Timeout = 10000;
                    response = (HttpWebResponse)request.GetResponse();
                    ru = GetResponseBody(response);

                }
                catch (Exception ex)
                {


                    ru = "";
                }
                finally
                {

                    if (response != null)
                    {
                        response.Close();
                    }
                    if (request != null)
                    {
                        request.Abort();
                    }
                }
            }
            catch
            {


                ru = "";
            }
        } while (ru.Length < 5000 && cs < 3);
        return ru;
    }
    public string HttpGet(string url)
    {
        string ru = "";
        int cs = 0;
        do
        {
            cs++;
            try
            {
                HttpWebRequest request = null;
                HttpWebResponse response = null;
                try
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                    if (!url.Contains("https") && !url.Contains("http"))
                    {
                        url = "https:" + url;
                    }
                    //System.GC.Collect();
                    //System.Net.ServicePointManager.DefaultConnectionLimit = 512;
                    request = (HttpWebRequest)WebRequest.Create(url);
                    string[] allbr = File.ReadAllText(Server.MapPath("br.txt"), Encoding.UTF8).Split('|');
                    // string br = allbr[int.Parse(getprice(0, allbr.Length - 1))];
                    request.UserAgent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36";
                    request.Method = "GET";
                    System.Net.WebProxy proxy = new WebProxy("127.0.0.1", 1080);
                    request.Proxy = proxy;
                    //request.ServicePoint.Expect100Continue = false;
                    //request.ServicePoint.UseNagleAlgorithm = false;
                    //request.AllowWriteStreamBuffering = false;
                    //request.ServicePoint.ConnectionLimit = 65500;
                    request.ContentType = "text/html";
                    // request.Headers.Add("Accept-Language", Request.QueryString["hl"]);
                    //request.Headers.Add("Accept-Encoding", "gzip");
                    request.Timeout = 10000;
                    response = (HttpWebResponse)request.GetResponse();
                    ru = GetResponseBody(response);

                }
                catch
                {
                    ru = "";
                }
                finally
                {

                    if (response != null)
                    {
                        response.Close();
                    }
                    if (request != null)
                    {
                        request.Abort();
                    }
                }
            }
            catch
            {


                ru = "";
            }
        } while (ru.Length < 5000 && cs < 3);
        return ru;
    }
    public string HttpPost(string url)
    {
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        Stream myResponseStream = null;
        StreamReader myStreamReader = null;
        try
        {
            try
            {

                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                //string url = "https://api.bazaarvoice.com/data/batch.json?" + "passkey=caPCsWJ9PpBOzvyJB7i1KVeIm0fHAOleTos4OW4jYMbKw&apiversion=5.5&displaycode=13107-en_us&resource.q0=products&filter.q0=id:eq:" + id + "&stats.q0=reviews&filteredstats.q0=reviews&filter_reviews.q0=contentlocale:eq:en*,en_US&filter_reviewcomments.q0=contentlocale:eq:en*,en_US&resource.q1=reviews&filter.q1=isratingsonly:eq:false&filter.q1=productid:eq:" + id + "&filter.q1=contentlocale:eq:en*,en_US&sort.q1=relevancy:a1&stats.q1=reviews&filteredstats.q1=reviews&include.q1=authors,products,comments&filter_reviews.q1=contentlocale:eq:en*,en_US&filter_reviewcomments.q1=contentlocale:eq:en*,en_US&filter_comments.q1=contentlocale:eq:en*,en_US&limit.q1=" + count + "&offset.q1=0";
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;


                request = (HttpWebRequest)WebRequest.Create(url);
                //string[] allbr = File.ReadAllText(Server.MapPath("br.txt"), Encoding.UTF8).Split('|');
                //string br = allbr[int.Parse(getprice(0, allbr.Length - 1))];
                request.UserAgent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36";
                request.Method = "GET";
                // System.Net.WebProxy proxy = new WebProxy("127.0.0.1", 1080);
                //request.Proxy = proxy;
                //request.ServicePoint.Expect100Continue = false;
                //request.ServicePoint.UseNagleAlgorithm = false;
                //request.AllowWriteStreamBuffering = false;
                //request.ServicePoint.ConnectionLimit = 65500;

                request.Headers.Add("Accept-Language", "en-us");
                request.Timeout = 10000;
                response = (HttpWebResponse)request.GetResponse();
                myResponseStream = response.GetResponseStream();
                myStreamReader = new StreamReader(myResponseStream, System.Text.Encoding.GetEncoding("utf-8"));
                string retString = myStreamReader.ReadToEnd();
                myStreamReader.Close();
                myResponseStream.Close();
                return retString;
            }
            catch
            {

                return "";
            }
            finally
            {
                if (myStreamReader != null)
                {
                    myStreamReader.Close();
                }
                if (myResponseStream != null)
                {
                    myResponseStream.Close();
                }
                if (response != null)
                {
                    response.Close();
                }
                if (request != null)
                {
                    request.Abort();
                }
            }
        }
        catch
        {



            return "";
        }
    }
    public static List<string> GetValue(string str, string s, string e)
    {
        List<string> strList = new List<string>();
        Regex rg = new Regex("(?<=(" + s + "))[.\\s\\S]*?(?=(" + e + "))");
        System.Text.RegularExpressions.MatchCollection mc = rg.Matches(str);
        for (int i = 0; i < mc.Count; i++)
        {

            strList.Add(mc[i].Value); //获取结果   strList中为匹配的值


        }
        return strList;
    }
    public static List<string> GetValue(string str, string s, string e, string where)
    {
        List<string> strList = new List<string>();
        Regex rg = new Regex("(?<=(" + s + "))[.\\s\\S]*?(?=(" + e + "))", RegexOptions.Multiline | RegexOptions.Singleline);
        System.Text.RegularExpressions.MatchCollection mc = rg.Matches(str);
        for (int i = 0; i < mc.Count; i++)
        {
            if (mc[i].Value.Contains(where))
            {
                strList.Add(mc[i].Value); //获取结果   strList中为匹配的值
            }

        }
        return strList;
    }
    public static int[] getNum(int num, int minValue, int maxValue)
    {
        Random ra = new Random(unchecked((int)DateTime.Now.Ticks));
        int[] arrNum = new int[num];//注意:数组中各元素的初始值是0,当0在取值范围内时要另处理 
        int tmp = 0;
        for (int i = 0; i < num; i++)
        {
            tmp = getRandomNum(tmp, minValue, maxValue, ra);//取出值赋到数组中 

            if (Array.IndexOf(arrNum, tmp) < 0)//判断是否存在,不存在的话元素tmp的索引应为-1 
            {
                arrNum[i] = tmp;
            }
            else
            {
                i = i - 1;
            }
        }
        return arrNum;
    }
    public static int getRandomNum(int tmp, int minValue, int maxValue, Random ra)
    {
        tmp = ra.Next(minValue, maxValue);
        return tmp;
    }
}