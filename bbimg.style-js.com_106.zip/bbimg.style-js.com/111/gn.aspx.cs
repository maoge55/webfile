﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class JDNEW_gn : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["iid"] != null && Request.QueryString["iid"] != "")
            {
                SqlParameter[] para ={
                                     new SqlParameter("@iid",SqlDbType.Int)};


                para[0].Value = int.Parse(Request.QueryString["iid"]);
                DataSet dsimgs = GetDataSet("selectknamebyIID", para);
                if (access_sql.yzTable(dsimgs))
                {
                    xs = dsimgs.Tables[0].Rows[0]["kname"].ToString();
                }
            }
        }
    }
    public string xs = "";
    public static DataSet GetDataSet(string cmdText, params SqlParameter[] ps)
    {
        DataSet ds = new DataSet();
        try
        {
            using (SqlDataAdapter sda = new SqlDataAdapter(cmdText, ConfigurationSettings.AppSettings["SQLConnectionString"]))
            {
                if (ps != null)
                {
                    sda.SelectCommand.Parameters.AddRange(ps);
                }
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sda.Fill(ds);
            }
            return ds;
        }
        catch (Exception ex)
        {
            ds.Dispose();
            throw (ex);
        }
    }
}