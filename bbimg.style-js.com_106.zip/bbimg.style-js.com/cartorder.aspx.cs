﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class order : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bindshopcart();

        }
    }
    public string GetmyImg(string path)
    {
        if (path.ToLower().IndexOf("http://") != -1)
        {
            return "/lodimgtt/" + path.Replace("http://", "");
        }
        else
        {
            return path;
        }
    }
    public decimal ProductAmount = 0;
    public decimal yunfei = 0;
    public decimal Amount = 0;
    public int sl = 0;
    protected void bindshopcart()
    {
        if (Request.Cookies["csst"] != null)
        {
            if (Request.Cookies["csst"].Values.Count > 0)
            {
                //新建一个table
                DataTable Tbrv = new DataTable();
                Tbrv.Columns.Add("PID", typeof(string));
                Tbrv.Columns.Add("PNAME", typeof(string));
                Tbrv.Columns.Add("PIC", typeof(string));
                Tbrv.Columns.Add("PRICE", typeof(decimal));
                Tbrv.Columns.Add("PRICETYPE", typeof(string));
                Tbrv.Columns.Add("PCOUNT", typeof(int));
                Tbrv.Columns.Add("PSX", typeof(string));
                Tbrv.Columns.Add("PZONGJIA", typeof(decimal));
                Tbrv.Columns.Add("PCID", typeof(string));
                foreach (string item in Request.Cookies["csst"].Values)
                {

                    char[] sp = { '|' };

                    string[] fen = HttpUtility.UrlDecode(Request.Cookies["csst"][item]).Split(sp);
                    if (fen.Length > 2)
                    {
                        string PCID = fen[0].ToString() + "-" + fen[4].ToString();
                        string PID = fen[0].ToString();
                        string PNAME = access_sql.SubstringTonum(fen[5].ToString(), 40);
                        string PIC = fen[6].ToString();
                        decimal PRICE = Decimal.Parse(fen[2].ToString());
                        string PRICETYPE = fen[1].ToString();
                        int PCOUNT = Convert.ToInt32(fen[3].ToString());
                        sl += PCOUNT;
                        string PSX = "";
                        string[] qq = fen[4].ToString().Replace("ABC", "&").Replace("++", "镍").Split(new Char[] { '镍' }, StringSplitOptions.RemoveEmptyEntries);
                        PSX = qq[qq.Length - 1].ToString();
                        decimal PZONGJIA = PCOUNT * PRICE;
                        Tbrv.Rows.Add(new object[] { PID, PNAME, PIC, PRICE, PRICETYPE, PCOUNT, PSX, PZONGJIA, PCID });
                        ProductAmount += PZONGJIA;

                    }
                    else
                    {
                        Response.Redirect("/");
                    }

                }
                yunfei = getyunfei(ProductAmount);
                Amount = yunfei + ProductAmount;
                rp_shopcart.DataSource = Tbrv;
                rp_shopcart.DataBind();
            }
            else
            {
                Response.Redirect("/");
            }

        }
        else
        {
            Response.Redirect("/");
        }

    }
    public decimal getyunfei(decimal zj)
    {
        decimal ru = 0;
        DataRow dr = access_sql.GreatDs("select * from YunFei where Y_ID=1").Tables[0].Rows[0];
        if (dr != null)
        {
            if (zj < decimal.Parse(dr["Y_JiChu"].ToString()))
            {
                ru = decimal.Parse(dr["Y_DiZeng"].ToString());
            }

        }
        return ru;
    }
    public static string GetImg(string path, string colorid, string pid)
    {

        DataTable dtimg = access_sql.picpath(path);
        string hand = access_sql.GetOneValue("select color from product where p_id=" + pid).Split('|')[int.Parse(colorid)];
        if (hand.IndexOf("[") != -1)
        {
            string imgid = hand.Substring(hand.IndexOf("[") + 1, 1);
            return dtimg.Rows[int.Parse(imgid) - 1]["picpath"].ToString() == "" ? "" : dtimg.Rows[int.Parse(imgid) - 1]["picpath"].ToString();
        }
        else
        {
            return dtimg.Rows[0]["picpath"].ToString() == "" ? "" : dtimg.Rows[0]["picpath"].ToString();
        }

    }
}