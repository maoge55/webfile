var is_mobi = navigator.userAgent.toLowerCase().match(/(ipod|iphone|android|coolpad|mmp|smartphone|midp|wap|xoom|symbian|j2me|blackberry|wince)/i) != null;
if (is_mobi) {
    var q = document.location.href.replace("//", "*");
    var ym = q.substring(0, q.lastIndexOf("/"));
    var hm = q.replace(ym, "");
    var d = ym + "/M/" + hm;
    d = d.replace("//", "/").replace("*", "//");
    window.location.href = d;
}